/**
 * @ngdoc function
 * @name starter
 * @description
 * # App
 *
 */
'use strict';
angular.module('app', ['ionic', 'ionicControllers', 'ionicServices', 'lbServices', 'config', 'ngCordova', 'ngSanitize', 'ngMaterial', 'ngStorage', 'morphCarousel', 'aCarousel', 'onezone-datepicker', 'ionic-ratings'])
    .run(function($ionicPlatform,$http,$ionicPopup) {
        $ionicPlatform.ready(function() {

             
             if (ionic.Platform.isIOS() || ionic.Platform.isAndroid()) {
             if(window.cordova) {
        //$cordovaAppVersion.getVersionNumber().then(function (version) {
             var url = 'http://54.202.79.111:3000';
                        $http.post(url + '/getCustomerAppLiveVersion').
                                                    success(function(result) {
                                console.log('result:' + JSON.stringify(result));
var plVersion = result;
                        
                        console.log(plVersion);
                cordova.getAppVersion.getVersionNumber().then(function (version) {
            var version = version.replace(/\./g, "");
            console.log(version);
          if(Number(version)<Number(plVersion)){
             if(ionic.Platform.isAndroid())
        {
             var alertPopup = $ionicPopup.alert({
     title: 'Update Info',
     template: 'New version is available. Please update application to proceed.'
   });

   alertPopup.then(function(res) {
       cordova.plugins.market.open('com.indian.drivers.customer');
   });
             
        }
         
          }
           
        });
                
                      }).
                                                    error(function(error) {
                                                        // $cordovaDialogs.alert('Error......');
                                                      //  console.log('Error in updating driver invoiceDetails:' + JSON.stringify(error));
                                                    });
        
      }
  }
            // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
            // for form inputs)
            if (ionic.Platform.isAndroid() && window.cordova && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            }
            if (window.StatusBar) {
                // org.apache.cordova.statusbar required
                StatusBar.styleDefault();
            }

            //$cordovaSplashscreen.hide();
        });
    })

.config(function($ionicConfigProvider, $stateProvider, $urlRouterProvider, $mdGestureProvider) {

    $ionicConfigProvider.tabs.position('bottom'); // other values: top
    $ionicConfigProvider.navBar.alignTitle('center');

    $ionicConfigProvider.views.swipeBackEnabled(false);
    $ionicConfigProvider.views.transition('none');

    $mdGestureProvider.skipClickHijack();

    $stateProvider
    .state('landing', {
            cache: false,
            url: '/landing',
            templateUrl: 'templates/landing.html',
            controller: 'signInCtrl'
        })
        .state('signIn', {
            cache: false,
            url: '/signIn',
            templateUrl: 'templates/sign-in.html',
            controller: 'signInCtrl'
        })
        .state('terms', {
            cache: false,
            url: '/terms',
            templateUrl: 'templates/terms_and_conditions.html',
            controller: 'signInCtrl'
        })
        .state('signUp', {
            url: '/sign-up',
            templateUrl: 'templates/sign-up.html',
            controller: 'signUpCtrl'
        })
        .state('verifOTPNo', {
            url: '/verifyOTPNo',
            templateUrl: 'templates/verify-otp-no.html',
            controller: 'signInCtrl'
        })
         
        .state('myProfile', {
            cache: false,
            url: '/myProfile',
            templateUrl: 'templates/my-profile.html',
            controller: 'profileCtrl'
        })
        .state('myProfileInital', {
           cache: false,
           url: '/myProfileInitial',
           templateUrl: 'templates/initial-update-profile.html',
           controller: 'profileCtrl'
       })
        .state('currentBooking', {
            url: '/currentBooking',
            templateUrl: 'templates/current-booking.html',
            controller: 'currentBookingCtrl'
        })
         
        .state('newBooking', {
            url: '/newBooking',
            templateUrl: 'templates/new-booking.html',
            controller: 'bookingCtrl'
        })
        .state('confirmBooking', {
            cache: false,
            url: '/confirmBooking',
            templateUrl: 'templates/confirm-booking.html',
            controller: 'bookingCtrl'
        })
         .state('myBookings', {
            cache: false,
            url: '/myBookings',
            templateUrl: 'templates/my-bookings.html',
            controller: 'myBookingsCtrl'
        })
        .state('invoice', {
            cache: false,
            url: '/invoice',
            templateUrl: 'templates/invoice.html',
            controller: 'myBookingsCtrl'
        })
        .state('cancelBooking', {
            url: '/cancelBooking',
            templateUrl: 'templates/cancel-booking.html',
            controller: 'myBookingsCtrl'
        })
        .state('rateCard', {
            cache: false,
            url: '/rateCard',
            templateUrl: 'templates/rate-card.html',
            controller: 'MenuCtrl'
        })
         .state('lookingPdirver', {
            cache: false,
            url: '/lookingPdirver',
            templateUrl: 'templates/looking-for-permanent-driver.html',
            controller: 'lookPdriverCtrl'
        })
         .state('makePendingPayment', {
            cache: false,
            url: '/makePendingPayment',
            templateUrl: 'templates/pending-payment.html',
            controller: 'signInCtrl'
        })
         .state('feedback', {
            cache: false,
            url: '/feedback',
            templateUrl: 'templates/feedback.html',
            controller: 'MenuCtrl'
        })
         .state('call', {
            cache: false,
            url: '/call',
            templateUrl: 'templates/call-model.html',
            controller: 'MenuCtrl'
        })
         .state('aboutUs', {
           url: '/aboutUs',
           templateUrl: 'templates/about-us.html',
           controller: 'MenuCtrl'
       });
          
          

    $urlRouterProvider.otherwise('/landing');

});
