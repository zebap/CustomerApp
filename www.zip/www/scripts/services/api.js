'use strict';
/**
 * @ngdoc function
 * @name starter.services:api
 * @description
 * # API
 * Service of the app
 */
angular.module('ionicServices', [])
    .factory('API', function($rootScope, $http, $ionicLoading, $state) {

        $rootScope.show = function(text) {
            $ionicLoading.show({
                noBackdrop: false,
                animation: 'fade-in',
                showDelay: 0,
                template: '<ion-spinner icon="ios"></ion-spinner>'
            });
        };

        $rootScope.hide = function() {
            $ionicLoading.hide();
        };

        $rootScope.redirectURL = function(state, menuComponentId) {
            $state.go(state);
            $rootScope.menuComponentId = menuComponentId;
        };


        return {

            firstToUpperCase: function(str) {
                console.log('String: ' + str);
                return str.substr(0, 1).toUpperCase() + str.substr(1);
            },

            fbProfile: function(token) {
                console.log(token);
                return $http.get('https://graph.facebook.com/v2.2/me', {
                    params: {
                        access_token: token,
                        format: 'json'
                    }
                });
            },

            googleProfile: function(token) {
                console.log(token);
                return $http.get('https://www.googleapis.com/oauth2/v2/userinfo', {
                    params: {
                        access_token: token
                    }
                });
            }
        };
    });
