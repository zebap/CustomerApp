/**
 * @ngdoc function
 * @name starter.controller:bookingCtrl
 * @description
 * # bookingCtrl
 * Booking controller of the app
 */
'use strict';
angular.module('ionicControllers')
    .controller('currentBookingCtrl', ['$rootScope', '$scope', '$state', 'ENV', 'API', '$ionicModal', '$http', '$sce', '$interval', '$timeout', 'Bookings', '$cordovaDialogs', 'CustomerDetails', 'DriverDetails',
        function($rootScope, $scope, $state, ENV, API, $ionicModal, $http, $sce, $interval, $timeout, Bookings, $cordovaDialogs, CustomerDetails, DriverDetails) {

            var map1;
            var amtTimer;
            var w = window.innerWidth;
            var h = window.innerHeight;
            $scope.deviceHeight = 0;

            $rootScope.amount = 0;

            $rootScope.amountHTML = '<b>&#x20B9; ' + $rootScope.amount + '</b>';

            console.log('width: ' + w + ' height :' + h);

            if (ionic.Platform.isIOS()) {
                $scope.deviceHeight = h - 100; //- 143;
            } else if (ionic.Platform.isAndroid()) {
                $scope.deviceHeight = h - 88;
            } 
            var socket = io('http://52.32.39.44:3200');
             
            if ($rootScope.currentBookingDisable) {
                socket.on('curent_booking_socket_' + $rootScope.currentBooking[0].id, function(data) {
                    console.log('curent_booking_socket_' + $rootScope.currentBooking[0] + ': ' + JSON.stringify(data));

                    if (data[0].amount != 0) {
                         
                        $rootScope.amount = data[0].amount;
                        $scope.currentAmount();

                    }
                    console.log('Lat' + data[0].lat + ' Long' + data[0].lng)
                    var lat = data[0].lat;
                    var lng = data[0].lng;
                    if (lat != 0 && lng != 0) {
                        setDriverLocation(lat, lng);
                    }
                });
            }


            function setDriverLocation(lat, lng) {
                var driverLat = lat;
                var driverLong = lng;

                var driverLocation = new plugin.google.maps.LatLng(driverLat, driverLong);
if (angular.isDefined($rootScope.assetMarker)) {
                    $rootScope.assetMarker.setPosition(driverLocation);
                    $rootScope.map1.moveCamera({
                            'target': driverLocation,
                            'tilt': 30,
                            'zoom': 17,
                            'bearing': 140
                        },
                        function() {
                            console.log('camera move');
                        });
                    selectLocation('' + driverLocation.lat + ',' + driverLocation.lng);
                }
            }


            $scope.$on('$ionicView.enter', function(event, data) {
               var stateName = data.stateName;
                if (stateName === 'currentBooking') {

                    if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                        $rootScope.map.remove();
                        $rootScope.map = null;
                    }

                    $rootScope.menuComponentId = 'current-left';
                    fetchCurrentBookingsDetails();
                    $scope.initMap();
                    socket.connect();
                    $scope.fetchDriverCurrentLocation();

                }

            });

            function fetchCurrentBookingsDetails() {


                 
            }

            $scope.$on('$stateChangeStart',
                function(event, toState, toParams, fromState, fromParams) {
                    if (!angular.isUndefined($rootScope.map1) && $rootScope.map1 !== null) {
                        $rootScope.map1.remove();
                        $rootScope.map1 = null;
                    }

                    stopAmtTimer();
                    socket.disconnect();

                });

            $scope.initMap = function() {
                var div = document.getElementById("map_canvas1");
                map1 = plugin.google.maps.Map.getMap(div);
                map1.on(plugin.google.maps.event.MAP_READY, onMapInit);

                map1.on(plugin.google.maps.event.CAMERA_CHANGE, onMapCameraChanged);


            };

            function onMapInit(map) {
                map1.setOptions({
                    controls: {
                        compass: false,
                        myLocationButton: false
                    },
                    gestures: {
                        scroll: true,
                        tilt: true,
                        rotate: true,
                        zoom: true
                    }
                });
                console.log('Lat: ' + ENV.defaultLat + '\nLong: ' + ENV.defaultLong);
                map1.getMyLocation(onSuccess, onError);
                $rootScope.map1 = map1;
                $rootScope.map1.setClickable(true);

            }

            var onSuccess = function(location) {
                var LOCATION = new plugin.google.maps.LatLng(location.latLng.lat, location.latLng.lng);
                $rootScope.map1.setZoom(15);

                console.log("current position " + location.latLng);
                var latitude = location.latLng.lat;
                var longitude = location.latLng.lng;
                console.log('lat' + latitude + 'Lon ' + longitude);


                addAssetMarker(latitude, longitude); 
            };

            var onError = function(msg) {
                console.log('error fetching ,y location : ' + msg);
            };

            function onMapCameraChanged(position) {
                console.log('camera change called : ' + JSON.stringify(position));
                 
            }

            function selectLocation(position) {

                console.log('selectLocation position : ' + JSON.stringify(position));

                if ((position !== null) || (position !== undefined) || (position !== '')) {
                    $http({
                        method: 'GET',
                        url: 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' + position + '&sensor=true'
                    }).then(function successCallback(response) {
                            console.log('position : ' + JSON.stringify(response));

                            if (response.data.status !== 'ZERO_RESULTS' && position !== '0,0') {

                                var latlng = position.split(",");
                                var centerLocation = new plugin.google.maps.LatLng(latlng[0], latlng[1]);

                                $rootScope.formattedAddress = response.data.results[0].formatted_address;
                                console.log('formatted_address : ' + $rootScope.formattedAddress);

                            }

                        },
                        function errorCallback(response) {
                            console.log('errorCallback : ' + JSON.stringify(response));
                        });
                }
            }

            function addAssetMarker(lat, lng) {
                $rootScope.map1.addMarker({
                    'position': new plugin.google.maps.LatLng(lat, lng),
                    'title': 'Driver',
                    'icon': ENV.carMarker
                }, function(marker) {
                     
                    $rootScope.assetMarker = marker;
                    $scope.fetchDriverCurrentLocation();

                });
            }

            $scope.currentAmount = function() {
                
                $rootScope.amountHTML = '<b>&#x20B9; ' + Number($rootScope.amount).toFixed(2) + '</b>';
                
                return $sce.trustAsHtml($rootScope.amountHTML.toString());
            };

            $scope.fetchDriverCurrentLocation = function() {



                CustomerDetails.find({
                        filter: {
                            where: {
                                conuserId: $rootScope.user.id
                            }
                        }
                    },
                    function(response) {
                        console.log('Customer Object' + JSON.stringify(response[0]));
                        console.log('Customer Id' + JSON.stringify(response[0].id));

                        $scope.customerId = response[0].id;
                         Bookings.find({
                                filter: {
                                    where: {
                                        customerId: $scope.customerId,
                                        startOffDuty: true
                                    },
                                    include: {
                                        relation: 'invoices'
                                    }
                                }
                            },
                            function(response) {
                                console.log('Current Booking : ' + JSON.stringify(response));
                                if (response.length > 0) {
                                    $rootScope.currentBookingDisable = true;
                                    $rootScope.currentBooking = response;
                                    $rootScope.amount = response[0].invoices[0].netAmount;

                                    console.log('Driver Id Is' + JSON.stringify(response[0].driverId));

                                    DriverDetails.find({
                                            filter: {
                                                where: {
                                                    id: response[0].driverId
                                                },
                                                include: {
                                                    relation: 'conUsers'
                                                }
                                            }
                                        },
                                        function(response) {
                                            console.log('**********Driver Detail*********** ' + JSON.stringify(response));
                                            setDriverLocation(response[0].conUsers.addressLat, response[0].conUsers.addressLong);
                                        },
                                        function(error) {
                                            //$cordovaDialogs.alert('Error in fetching Driver Detail', 'My Booking');
                                        });

                                }
                            },
                            function(error) {
                                console.log('Error fetching current Booking : ' + JSON.stringify(error));
                            });



                    },
                    function(error) {
                       // $cordovaDialogs.alert('Error in Fetching Customer Id', 'Current Booking');
                    });


            };


            function countdown() {
                amtTimer = $timeout(function() {
                    console.log('$scope.amount : ' + $rootScope.amount);

                    countdown();
                    
                }, 1000);
            }

            function stopAmtTimer() {
                $timeout.cancel(amtTimer);
            }

        }
    ]);
