'use strict';
angular.module('ionicControllers')
    .controller('lookPdriverCtrl', ['$rootScope', '$scope', '$state', 'ENV', 'API', '$ionicModal', '$http', '$sce', '$interval', '$timeout', 'Bookings', '$cordovaDialogs', 'CustomerDetails', 'DriverDetails', 'ConUsers', '$localStorage', '$ionicLoading', '$ionicViewService', '$ionicHistory', 'PermanentDriverRequest','$ionicPopup',
        function($rootScope, $scope, $state, ENV, API, $ionicModal, $http, $sce, $interval, $timeout, Bookings, $cordovaDialogs, CustomerDetails, DriverDetails, ConUsers, $localStorage, $ionicLoading, $ionicViewService, $ionicHistory, PermanentDriverRequest,  $ionicPopup) {


            $rootScope.conId = $localStorage.user.customerId;
            $rootScope.selectedDays=[];
            $ionicModal.fromTemplateUrl('templates/permanent-driver-request-sucess.html', function($ionicThanksMsgModal1) {
                $scope.thanksMsgModal1 = $ionicThanksMsgModal1;
            }, {
                scope: $scope,
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(thanksMsgModal1) {
                $scope.thanksMsgModal1 = thanksMsgModal1;

            });
            $scope.subMenu =false;
            $scope.confirmModal = function() {

                console.log('costumer id ' + JSON.stringify($rootScope.conId));
                var remark = '';
                PermanentDriverRequest.createPermanentDriverRequestNew({
                    customerId: $rootScope.conId,
                    createdBy: $rootScope.ConUsers.user.id,
                    remark: ''

                }, function(success) {
                    console.log('Permanent Driver Request success :' + JSON.stringify(success));
                    //$cordovaDialogs.alert('Your request has been send successfully.');
                    if (success[0].create_permanent_driver_request_new === '0') {
                        $scope.thanksMsgModal1.show();
                    } else {
                        $cordovaDialogs.alert('Your request for monthly driver has already submitted.', 'Alert');
                    }

                }, function(err) {
                    console.log('Permanent Driver Request err ' + JSON.stringify(err));


                });
            };


/*-------new file------*/


$scope.carType = [
     {name:'Automatic'},
     {name:'Manual'}
     
   ];  
   //  $scope.weeklyOf = [
   //   {name:'Sunday'},
   //   {name:'Monday'},
   //   {name:'Tuesday'},
   //   {name:'Thursday'},
   //   {name:'Friday'},
   //   {name:'Saturday'}
     
   // ];
$scope.open = function () {
             if($scope.subMenu){
               $scope.subMenu =false;
             }else{
               $scope.subMenu =true;
             }
             
   $ionicPopup.show({
     templateUrl: 'orderPopup.html',
     title: 'Select days',
     scope: $scope,
     buttons: [{
       text: 'Ok',
       type: 'button-positive',
       onTap: function (request) {
        $scope.save();
        console.log('days: ' + JSON.stringify(request))
       }
     }]
   });
 }




$scope.listPref = [
    { text: 'Monday', id: '1' },
    { text: 'Tuesday', id: '2' },
    { text: 'Wednesday', id: '3' },
    { text: 'Thursday', id: '4' },
    { text: 'Friday', id: '5' },
    { text: 'Saturday', id: '6' },
    { text: 'Sunday', id: '7' }
];
$scope.weeklyOff = { }

$scope.print = function() {
    console.log($scope.weeklyOff);
     
}

$scope.save = function() {
    $rootScope.days = [];
    $rootScope.selectedDays=[];
    var i;
    for(i in $scope.weeklyOff) {
        console.log($scope.weeklyOff[i]);
        if($scope.weeklyOff[i] == true) {
           $rootScope.days.push(i);
           if(i==='1'){
            $rootScope.selectedDays.push('Monday');
          }else if(i==='2'){
            $rootScope.selectedDays.push('Tuesday');
          }else if(i==='3'){
            $rootScope.selectedDays.push('Wednesday');
          }else if(i==='4'){
            $rootScope.selectedDays.push('Thursday');
          }else if(i==='5'){
            $rootScope.selectedDays.push('Friday');
          }else if(i==='6'){
            $rootScope.selectedDays.push('Saturday');
          }else if(i==='7'){
            $rootScope.selectedDays.push('Sunday');
          }
           /*if($rootScope.days.length>0){
            for(var k=0; k<$rootScope.days.length;k++){

               if($rootScope.days[k] === '1'){
            $rootScope.selectedDays.push('Monday');
           }else if($rootScope.days[k] === '2'){
            $rootScope.selectedDays.push('Tuesday');
          }else if($rootScope.days[k] === '3'){
            $rootScope.selectedDays.push('Wednesday');
           }else if($rootScope.days[k] === '4'){
            $rootScope.selectedDays.push('Thursday');
           }else if($rootScope.days[k] === '5'){
            $rootScope.selectedDays.push('Friday');
           }else if($rootScope.days[k] === '6'){
            $rootScope.selectedDays.push('Saturday');
           }else if($rootScope.days[k] === '7'){
            $rootScope.selectedDays.push('Sunday');
           }
            }
           
           }*/
           
        }
    }
    console.log($rootScope.selectedDays);
    console.log($rootScope.days);

}
 $scope.confirmModal = function(request) {


                         var dutyHrs = 0;
                            var cartp = '';
                         /*  var weeklf =  '{}';*/
                            var salarybdgt = '';
                            var naturefduty = '';

                            if(angular.isDefined(request)){
                              if (angular.isDefined(request.carTypes) ) {
                             cartp =  request.carTypes; 
                         }
                          if (angular.isDefined(request.dutyHours) ) { 
                                dutyHrs = request.dutyHours; 
                            }

                           /* if (angular.isDefined(request.weeklyOff) ) {
                          weeklf = '{' + request.weeklyOff + '}';
                              }*/

                            if (angular.isDefined(request.salaryBudget) ) { 
                                salarybdgt = request.salaryBudget; 
                            }

                            if (angular.isDefined(request.natureOfDuty) ) { 
                                naturefduty = request.natureOfDuty; 
                            }

                          } 
                          if(angular.isDefined($rootScope.days)){
                            var wklyoff = '{' + $rootScope.days + '}';
                            
                          }else{
                            var wklyoff = '{}';
                          }

                            

                
               PermanentDriverRequest.createPermanentDriverRequestNewBoth({
                   customerId: $rootScope.conId,
                   createdBy: $rootScope.ConUsers.user.id,
                   remark: '',
                   carType: cartp,
                   dutyHours: dutyHrs,
                  salaryBudget: salarybdgt,
                   naturOfDuty: naturefduty,
                      weeklyOff: wklyoff

                  }, function(success) {
                   console.log('Permanent Driver Request success :' + JSON.stringify(success));
                   //$cordovaDialogs.alert('Your request has been send successfully.');
                   if (success[0].create_permanent_driver_request_new_both === '0') {
                        $scope.thanksMsgModal1.show();
                    } else {
                        $cordovaDialogs.alert('Your request for monthly driver has already submitted.', 'Alert');
                    }
                    
                   
               }, function(err) {
                   console.log('Permanent Driver Request err ' + JSON.stringify(err));
                   

               });
           };

            $scope.closeThanksModal1 = function() {
                $scope.thanksMsgModal1.hide();
                if (angular.isDefined($rootScope.map)) {
                    $rootScope.map.setClickable(true);
                }
                $state.go('newBooking');
            };

            $scope.closePdriver = function() {
                $scope.thanksMsgModal1.hide();
                $scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $ionicViewService.nextViewOptions({
                    disableBack: true
                });
                $ionicViewService.clearHistory();
                $ionicHistory.clearHistory();
                $state.go('newBooking');
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);

            };



        }
    ]);