(function() {
    'use strict';
    /**
     * @ngdoc function
     * @name starter.controller:bookingCtrl
     * @description
     * # bookingCtrl


     * Booking controller of the app
     */
    angular.module('ionicControllers')
        .controller('bookingCtrl', ['$rootScope', '$scope', '$state', 'ENV', 'API', '$http', '$ionicModal', '$ionicLoading', '$mdMenu', 'FareMatrix', '$cordovaDialogs', '$filter', 'Bookings', 'LocalBookings', 'OutstationBookings', 'Invoices', '$timeout', 'CustomerDetails', 'CustomerFavouriteAddresses', '$ionicScrollDelegate', 'DriverDetails', '$mdSidenav', 'ConUsers', '$ionicHistory', 'ExceptionOutstationCity', 'RateCard', '$sce', 'Cities',
            function($rootScope, $scope, $state, ENV, API, $http, $ionicModal, $ionicLoading, $mdMenu, FareMatrix, $cordovaDialogs, $filter, Bookings, LocalBookings, OutstationBookings, Invoices, $timeout, CustomerDetails, CustomerFavouriteAddresses, $ionicScrollDelegate, DriverDetails, $mdSidenav, ConUsers, $ionicHistory, ExceptionOutstationCity, RateCard, $sce, Cities) {
                $scope.subMenu = false;
                var map;
                $scope.inValidAddress = null;
                $scope.inValidAddress2 = null;
                $scope.inValidAddress3 = null;
                $scope.invalidCity = null;
                var originatorEv;
                this.topDirections = ['left', 'up'];
                this.bottomDirections = ['down', 'right'];
                this.isOpen = false;
                this.availableModes = ['md-fling', 'md-scale'];
                this.selectedMode = 'md-scale';
                this.availableDirections = ['up', 'down', 'left', 'right'];
                this.selectedDirection = 'left';
                $scope.isDisabled = false;
                $scope.dateerror = null;
                $scope.timeerror = null;
                $scope.invalidDutyHours = null;
                $rootScope.formattedAddress = 'Select a location';
                $rootScope.hourArray = ENV.hourArray;
                $rootScope.minuteArray = ENV.minuteArray;
                $rootScope.timeArray = ENV.timeArray;
                $rootScope.carTypeArray = ENV.carTypeArray;
                $rootScope.paymentModeArray = ENV.paymentModeArray;

                $rootScope.dutyTypeArray = ENV.dutyTypeArray;
                $rootScope.journeyTypeArray = ENV.journeyTypeArray;

                $scope.cancelReasonId = 'Select';
                $scope.selectedCityFlag = true;
                $scope.selectDropLocationFlag = true;
                $scope.reportingTimeValidationFlag = true;
                $scope.showBookingConfirmationFlag = true;
                $scope.repInvalidTimeFlag = true;
                $scope.validReportingTime = null;
                $scope.customerId = null;
                //$scope.isPickupLocationPune = false;
                $scope.isPickupLocationPune = true;
                $rootScope.paymentModeSeleted = true;

                $rootScope.setCurrentLocationFlag = 0;



                var months = ENV.monthArray;

                var daysOfTheWeek = ENV.dayArray;

                var d1 = new Date();

                d1.setDate(d1.getDate() + 8);

                var endDate = d1;

                var timer;

                           
                  Cities.find({
                           
                   },function(citysuccess){
                       
                      $rootScope.operationCities = [];
        for(var i = 0; i<citysuccess.length; i++){
            
            if(citysuccess[i].cityName !== 'All'){
                $rootScope.operationCities.push(citysuccess[i].cityName);
            }
        }


                   },function(cityerr){ 
                 
                   });
              
                  $scope.getAddress =function(){
                    ConUsers.findById({
                            id:$rootScope.conuserId

                        },
                        function(success){
                           

                            $rootScope.operationCity = success.operationCity;
                              
                            $rootScope.landmark = success.address;
                            $rootScope.pickupAddress = success.addressLine2;
                             console.log('success update:'+JSON.stringify(success));

                             $rootScope.bookingDetails = {
                        
                        pickupAddress: $rootScope.pickupAddress,
                        landmark: $rootScope.landmark
                         
                    };

                        },
                        function(error){
                              console.log('error:'+JSON.stringify(error));
                        });
                  }
                $scope.countdown = function() {
                    timer = $timeout(function() {

                        var tempDate = new Date();
                        var tempDate2 = new Date();

                        tempDate.setHours(0, 0, 0, 0);

                        tempDate2.setHours(tempDate2.getHours() + 2, 0, 0, 0);

                        Bookings.find({
                                filter: {
                                    where: {
                                        customerId: $rootScope.user.customerId,
                                        status: {
                                            inq: ['New Booking', 'Lined Up', 'In Progress']
                                        },
                                        reportingDate: tempDate,
                                        reportingTime: {
                                            lt: (tempDate2.getHours() + ':' + tempDate2.getMinutes())
                                        }
                                    },
                                    order: 'reportingDate ASC',
                                    limit: 1
                                }
                            },
                            function(response) {

                                if (response.length > 0) {
                                    $rootScope.currentBookingId = response[0].id;
                                }
                            },
                            function(error) {

                            });
                        $scope.countdown();
                    }, 1000);
                };
                $scope.stopTimer = function() {
                    $timeout.cancel(timer);
                };

                $scope.openMenu = function($mdOpenMenu, ev) {
                    $scope.closeOthers();
                    originatorEv = ev;
                    $mdOpenMenu(ev);
                };

                $scope.closeOthers = function() {
                    $mdMenu.hide(null, {
                        closeAll: true
                    });
                };
                $scope.closeOthers1 = function() {
                    $rootScope.show();
                    $mdMenu.hide(null, {
                        closeAll: true
                    });
                    $scope.showBookingConfirmation();
                };

                $scope.resetBookingDetails = function() {
                    $scope.releivingDatepicker.date = null;
                    $rootScope.locationFlag = 'pickup';
                    $rootScope.headerTitle = 'Book My Driver';
                    $rootScope.footerTitle = 'Book My Driver';
                    $scope.isDisabled = false;

                    var date = new Date();
                    var curr_hour = date.getHours();
                    if (curr_hour >= 6 && curr_hour < 22) {} else {
                        date.setDate(date.getDate() + 1);
                    }

                    $rootScope.bookingDetails = {
                        rptDate: date,
                        rptHour: null,
                        rptMinute: null,
                        rptTime: null,
                        relDate: date,
                        relHour: null,
                        relMinute: null,
                        relTime: null,
                        pickupAddress: $rootScope.pickupAddress,
                        pickupLat: null,
                        pickupLng: null,
                        dropAddress: null,
                        dropLat: null,
                        dropLng: null,
                        landmark: $rootScope.landmark,
                        routeType: 'Round Trip',
                        carType: 'Manual',
                        paymentMode: 'Cash',
                        dutyType: 'Local',
                        outstationCity: 'Select Outstation City',
                        outstationCityLat: null,
                        outstationCityLng: null
                    };

                }

                $scope.reportingDatepicker = {
                    date: new Date(),
                    mondayFirst: false,
                    months: months,
                    daysOfTheWeek: daysOfTheWeek,
                    endDate: endDate,
                    disablePastDays: true,
                    disableSwipe: false,
                    disableWeekend: false,
                    showDatepicker: false,
                    showTodayButton: true,
                    calendarMode: false,
                    hideCancelButton: false,
                    hideSetButton: true,
                    callback: function(value) {

                        $rootScope.bookingDetails.rptDate = value;
                    }
                };

                $scope.releivingDatepicker = {
                    //date: new Date(),
                    mondayFirst: false,
                    months: months,
                    daysOfTheWeek: daysOfTheWeek,
                    disablePastDays: true,
                    disableSwipe: false,
                    disableWeekend: false,
                    showDatepicker: false,
                    showTodayButton: true,
                    calendarMode: false,
                    hideCancelButton: false,
                    hideSetButton: true,
                    callback: function(value) {

                        $rootScope.bookingDetails.relDate = value;
                    }
                };
                $scope.change = function() {
                    $scope.releivingDatepicker = {
                        date: new Date(),
                        mondayFirst: false,
                        months: months,
                        daysOfTheWeek: daysOfTheWeek,
                        disablePastDays: true,
                        disableSwipe: false,
                        disableWeekend: false,
                        showDatepicker: false,
                        showTodayButton: true,
                        calendarMode: false,
                        hideCancelButton: false,
                        hideSetButton: true,
                        callback: function(value) {

                            $rootScope.bookingDetails.relDate = value;
                        }
                    };
                }

                $scope.$on('$ionicView.enter', function(event, data) {


                    var stateName = data.stateName;
                    if (stateName === 'newBooking') {
                        $rootScope.menuComponentId = 'map-left';
                        $scope.resetBookingDetails();
                        setMapHeight();
                        $scope.initMap();
                        $scope.locationMarker = ENV.locationMarker;
                    }

                });

                function setMapHeight() {

                    var w = window.innerWidth;
                    var h = window.innerHeight;
                    $scope.deviceHeight = 0;



                    if (ionic.Platform.isIOS()) {
                        $scope.deviceHeight = h - 100;
                        $scope.deviceWidth = (w - 24) / 2;
                        $scope.markerHeight = (parseInt($scope.deviceHeight) - 110) / 2;
                        $scope.mapMarginTop = 64;
                        $rootScope.menuTop = 64;
                        $scope.menuBtnTop = 15;
                        if (h <= 480) {
                            $rootScope.thanksTop = 40;
                            $rootScope.modalTop = 5;
                        } else {
                            $rootScope.thanksTop = 55;
                            $rootScope.modalTop = 5;

                        }

                    } else if (ionic.Platform.isAndroid()) {
                        $scope.deviceHeight = h - 88;
                        $scope.deviceWidth = (w - 24) / 2;
                        $scope.markerHeight = ($scope.deviceHeight - 110) / 2;
                        $scope.mapMarginTop = 44;
                        $rootScope.menuTop = 44;
                        $scope.menuBtnTop = 0;

                        if (h <= 480) {
                            $rootScope.thanksTop = 40;
                            $rootScope.modalTop = 0;
                        } else {
                            $rootScope.thanksTop = 55;
                            $rootScope.modalTop = 0;
                        }
                    }

                }

                $scope.$on('$stateChangeStart',
                    function(event, toState, toParams, fromState, fromParams) {


                        if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                            $rootScope.map.setClickable(false);
                        }

                        $scope.stopTimer();

                    });

                $scope.initMap = function() {

                    if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                        $rootScope.map.setClickable(true);

                        var div = document.getElementById('map_canvas');
                        map = plugin.google.maps.Map.getMap(div);


                    } else {

                        var div = document.getElementById('map_canvas');
                        map = plugin.google.maps.Map.getMap(div);

                        map.on(plugin.google.maps.event.MAP_READY, onMapInit);

                        map.on(plugin.google.maps.event.CAMERA_CHANGE, onMapCameraChanged);

                    }

                };

                function onMapInit(map) {
                    map.setOptions({
                        controls: {
                            compass: false,
                            myLocationButton: false
                        },
                        gestures: {
                            scroll: true,
                            tilt: true,
                            rotate: true,
                            zoom: true
                        }
                    });


                    var defaultLocation = new plugin.google.maps.LatLng(ENV.defaultLat, ENV.defaultLong);

                    map.setCenter(defaultLocation);
                    map.getMyLocation(onSuccess, onError);
                    $rootScope.map = map;
                    $rootScope.map.setClickable(true);
                }

                var onSuccess = function(location) {
                    var LOCATION = null;

                    $ionicHistory.clearHistory();

                    if ($rootScope.setCurrentLocationFlag == 1) {
                        $rootScope.setCurrentLocationFlag = 0;
                        LOCATION = new plugin.google.maps.LatLng(location.latLng.lat, location.latLng.lng);

                    } else {



                        if ($rootScope.user.addressLat == null || $rootScope.user.addressLong == null) {
                            LOCATION = new plugin.google.maps.LatLng(location.latLng.lat, location.latLng.lng);
                        } else {
                            LOCATION = new plugin.google.maps.LatLng($rootScope.user.addressLat, $rootScope.user.addressLong);
                        }

                    }

                    $rootScope.map.setZoom(15);



                    var position = location.latLng;

                    var latitude = location.latLng.lat;
                    var longitude = location.latLng.lng;

                    $rootScope.map.moveCamera({
                            'target': LOCATION,
                            'tilt': 30,
                            'zoom': 17,
                            'bearing': 140
                        },
                        function() {

                        });
                };

                var onError = function(msg) {

                };

                function onMapCameraChanged(position) {
                    $rootScope.currentLocationLat = position.target.lat.toFixed(4);
                    $rootScope.currentLocationLng = position.target.lng.toFixed(4);
                    selectLocation('' + position.target.lat + ',' + position.target.lng);
                }

                function selectLocation(position) {



                    if ((position !== null) || (position !== undefined) || (position !== '')) {
                        $http({
                            method: 'GET',
                            url: 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' + position + '&sensor=true&key=AIzaSyBlXlx9TZQ2MRMxeZHwQ5PX5hozA0vklcE'
                        }).then(function successCallback(response) {

                                if (response.data.status !== 'ZERO_RESULTS' && position !== '0,0') {

                                    var latlng = position.split(',');
                                    var centerLocation = new plugin.google.maps.LatLng(latlng[0], latlng[1]);

                                    $scope.position = position;
                                    if (!angular.isUndefined(response)) {
                                        $rootScope.addressDetail = response;
                                    }


                                    if (!angular.isUndefined(response.data.results[0])) {
                                        $rootScope.formattedAddress = response.data.results[0].formatted_address;
                                    }



                                    var i;
                                    $scope.isPickupLocationPune = true;

                                    if (!angular.isUndefined($rootScope.addressDetail.data.results[0])) {
                                        for (i = 0; i <= $rootScope.addressDetail.data.results[0].address_components.length; i++) {


                                            if (!angular.isUndefined($rootScope.addressDetail.data.results[0].address_components[i])) {

                                                if ($rootScope.addressDetail.data.results[0].address_components[i].types[0] === 'administrative_area_level_2') {

                                                    if ($rootScope.addressDetail.data.results[0].address_components[i].long_name === 'Pune') {
                                                        $scope.isPickupLocationPune = true;

                                                    }

                                                }

                                            }

                                        }

                                    }

                                }

                            },
                            function errorCallback(response) {

                            });
                    }
                }
                $scope.openCallModel = function() {
                    $rootScope.call = true;

                }


                $ionicModal.fromTemplateUrl('templates/address-modal.html', function($ionicAddressModal) {
                    $scope.addressModal = $ionicAddressModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-up',
                    backdropClickToClose: true,
                    hardwareBackButtonClose: true,
                    focusFirstInput: true
                }).then(function(addressModal) {
                    $scope.addressModal = addressModal;

                });
                $ionicModal.fromTemplateUrl('templates/reporting-date-modal.html', function($ionicRptDateModal) {
                    $scope.rptDateModal = $ionicRptDateModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(rptDateModal) {
                    $scope.rptDateModal = rptDateModal;

                });
                $ionicModal.fromTemplateUrl('templates/landmark-modal.html', function($ionicLandmarkModal) {
                    $scope.landmarkModel = $ionicLandmarkModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true,
                    focusFirstInput: true
                }).then(function(rptLandmarkModal) {
                    $scope.landmarkModel = rptLandmarkModal;

                });

                $ionicModal.fromTemplateUrl('templates/releiving-time-modal.html', function($ionicRelTimeModal) {
                    $scope.relTimeModal = $ionicRelTimeModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(relTimeModal) {
                    $scope.relTimeModal = relTimeModal;

                });



                $ionicModal.fromTemplateUrl('templates/releiving-date-modal.html', function($ionicRelDateModal) {
                    $scope.relDateModal = $ionicRelDateModal;
                }, {

                    scope: $scope,

                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(relDateModal) {
                    $scope.relDateModal = relDateModal;

                });



                $ionicModal.fromTemplateUrl('templates/booking-confirmation-modal.html', function($ionicBookingConfirmModal) {
                    $scope.bookConfirmModal = $ionicBookingConfirmModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(bookConfirmModal) {
                    $scope.bookConfirmModal = bookConfirmModal;

                });

                $ionicModal.fromTemplateUrl('templates/confirm-booking-rate-card-Local-RoundTrip-modal.html', function($ionicConfirmBookingRateCardLocalRoundTrip) {
                    $scope.confirmBookingRateCardLocalRoundTripModal = $ionicConfirmBookingRateCardLocalRoundTrip;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(confirmRateCardLocalRoundTrip) {
                    $scope.confirmBookingRateCardLocalRoundTripModal = confirmRateCardLocalRoundTrip;

                });

                $ionicModal.fromTemplateUrl('templates/confirm-booking-rate-card-Local-OneWay-modal.html', function($ionicConfirmBookingRateCardLocalOneWay) {
                    $scope.confirmBookingRateCardLocalOneWayModal = $ionicConfirmBookingRateCardLocalOneWay;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(confirmRateCardLocalOneWay) {
                    $scope.confirmBookingRateCardLocalOneWayModal = confirmRateCardLocalOneWay;

                });

                $ionicModal.fromTemplateUrl('templates/confirm-booking-rate-card-Outstation-RoundTrip-modal.html', function($ionicConfirmBookingRateCardOutstationRoundTrip) {
                    $scope.confirmBookingRateCardOutstationRoundTripModal = $ionicConfirmBookingRateCardOutstationRoundTrip;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(confirmRateCardOutstationRoundTrip) {
                    $scope.confirmBookingRateCardOutstationRoundTripModal = confirmRateCardOutstationRoundTrip;

                });

                $ionicModal.fromTemplateUrl('templates/confirm-booking-rate-card-Outstation-OneWay-modal.html', function($ionicConfirmBookingRateCardOutstationOneWay) {
                    $scope.confirmBookingRateCardOutstationOneWayModal = $ionicConfirmBookingRateCardOutstationOneWay;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(confirmRateCardOutstationOneWay) {
                    $scope.confirmBookingRateCardOutstationOneWayModal = confirmRateCardOutstationOneWay;

                });


                $ionicModal.fromTemplateUrl('templates/booking-details-modal.html', function($ionicBookingDetailsModal) {
                    $scope.bookDetailsModal = $ionicBookingDetailsModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(bookDetailsModal) {
                    $scope.bookDetailsModal = bookDetailsModal;

                });
                $ionicModal.fromTemplateUrl('templates/thanks-message-modal.html', function($ionicThanksMsgModal) {
                    $scope.thanksMsgModal = $ionicThanksMsgModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(thanksMsgModal) {
                    $scope.thanksMsgModal = thanksMsgModal;

                });


                $ionicModal.fromTemplateUrl('templates/search-modal.html', function($ionicSearchModal) {
                    $scope.searchModal = $ionicSearchModal;
                }, {
                    scope: $scope,
                    focusFirstInput: true,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true,
                    focusFirstInput: true
                }).then(function(searchModal) {
                    $scope.searchModal = searchModal;

                });

                $ionicModal.fromTemplateUrl('templates/outstation-city-modal.html', function($ionicOutCityModal) {
                    $scope.outCityModal = $ionicOutCityModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true,
                    focusFirstInput: true
                }).then(function(outCityModal) {
                    $scope.outCityModal = outCityModal;

                });



                $ionicModal.fromTemplateUrl('templates/payment-mode-modal.html', function($ionicOutCityModal) {
                    $scope.paymentModeModal = $ionicOutCityModal;
                }, {
                    scope: $scope,
                    animation: 'slide-in-left',
                    backdropClickToClose: false,
                    hardwareBackButtonClose: true
                }).then(function(paymentModeModal) {
                    $scope.paymentModeModal = paymentModeModal;

                });


                $scope.$on('modal.hidden', function() {

                    if ((!angular.isUndefined($rootScope.map))) {}
                });
                $scope.$on('modal.removed', function() {

                    if ((!angular.isUndefined($rootScope.map))) {}
                });
                $rootScope.openAddressModal = function() {
                    $rootScope.currentBookingDisable = false;
                    CustomerDetails.find({
                            filter: {
                                where: {
                                    conuserId: $rootScope.user.id
                                }
                            }
                        },
                        function(response) {

                            $scope.customerId = response[0].id;
                            Bookings.find({
                                    filter: {
                                        where: {
                                            customerId: $scope.customerId,
                                            startOffDuty: true
                                        }
                                    }
                                },
                                function(response) {

                                    if (response.length > 0) {
                                        $rootScope.currentBookingDisable = true;
                                        $rootScope.currentBooking = response;
                                        redirectToURL('currentBooking', 'current-left');
                                    } else {
                                        Bookings.find({
                                                filter: {
                                                    where: {
                                                        customerId: $scope.customerId,
                                                        status: {
                                                            inq: ['Paid', 'Done']
                                                        }
                                                    },
                                                    include: [{
                                                        relation: 'invoices',
                                                        scope: {
                                                            include: {
                                                                relation: 'invoiceDetails',
                                                                scope: {
                                                                    include: {
                                                                        relation: 'invoiceSubHeads'
                                                                    }
                                                                }
                                                            },
                                                            order: 'id DESC',
                                                            limit: 1
                                                        }
                                                    }, {
                                                        relation: 'localBookings'
                                                    }, {
                                                        relation: 'outstationBookings'
                                                    }],
                                                    order: 'id DESC',
                                                    limit: 1
                                                }
                                            },
                                            function(response) {

                                                $rootScope.bookingDetail = response;
                                                if (angular.isDefined($rootScope.bookingDetail[0])) {
                                                if (angular.isDefined($rootScope.bookingDetail[0].outstationBookings[0])) {
                                                    if ($rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime === null) {
                                                        $rootScope.time1 = 0 + ' Hours ' + 0 + ' Minutes';
                                                    } else {
                                                        var returnTime = $rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime.toFixed(2);
                                                        var array = returnTime.split('.');
                                                        var returnTravelHour = parseInt(array[0]);
                                                        var returnTravelMinute = parseInt(array[1]);
                                                        if (returnTravelMinute < 10) {
                                                            returnTravelMinute = '0' + returnTravelMinute;
                                                        }
                                                        returnTravelMinute = returnTravelMinute * 0.6;
                                                        returnTravelMinute = Math.round(returnTravelMinute);
                                                        $rootScope.time1 = returnTravelHour + ' Hours ' + returnTravelMinute + ' Minutes';

                                                    }
                                                }
                                            }
                                                $rootScope.baseFare = null;
                                                $rootScope.returnFare = null;
                                                if (response.length !== 0) {
                                                    if (response[0].driverId != null) {
                                                        DriverDetails.find({
                                                                filter: {
                                                                    where: {
                                                                        id: response[0].driverId
                                                                    },
                                                                    include: {
                                                                        relation: 'conUsers'
                                                                    }
                                                                }
                                                            },
                                                            function(response) {
                                                                $rootScope.driverDetailOfViewBooking = response;

                                                            },
                                                            function(error) {
                                                                //$cordovaDialogs.alert('Error in fetching Driver Detail', 'My Booking');
                                                            });
                                                    }
                                                    $rootScope.viewInvoiceDetail = response[0].invoices[0].invoiceDetails;
                                                }

                                                $state.go('invoice');
                                            },
                                            function(error) {

                                            });
                                    }
                                },
                                function(error) {

                                });
                        },
                        function(error) {

                        });
                };


                function redirectToURL(stateName, menuComponentId) {
                    $state.go(stateName);
                    $scope.close();
                    $rootScope.menuComponentId = menuComponentId;
                };

                $scope.close = function() {
                    $mdSidenav($rootScope.menuComponentId).close()
                        .then(function() {

                        });
                };
                $scope.closeAddressModal = function() {
                    $scope.addressModal.hide();
                };



                $scope.setRouteAddress = function(formattedAddress) {
                    $rootScope.enableText = true;
                    $rootScope.enableText1 = false;
                    // resetBookingDetails();
                    if($rootScope.footerTitle != 'Set As Drop Location'){

                        var land = $rootScope.bookingDetails.landmark + ', ';
                         
                            $rootScope.bookingDetails.pickupAddress = formattedAddress.replace(land, '');
                                            $rootScope.bookingDetails.pickupAddress = $rootScope.bookingDetails.pickupAddress.replace(/, Maharashtra/g, '');
                                            $rootScope.bookingDetails.pickupAddress = $rootScope.bookingDetails.pickupAddress.replace(/, India/g, '');

                            $scope.openLandmarkModel();
                                            
                    }else{
                            if(angular.isUndefined(formattedAddress) || formattedAddress === '' || formattedAddress === null){
                                $scope.inValidAddress3 = 'Drop address is compulsory';
                        }else{
                            $scope.inValidAddress3 = null;
                            $scope.selectDropLocationFlag = true;
                         $rootScope.bookingDetails.dropAddress = formattedAddress;
                         $scope.openBookingDetailsModal();
                        }
                        
                    }

                

                };
                $scope.test = function() {
                    document.getElementById('test').focus();
                };
                $scope.openLandmarkModel = function() {

                    if($rootScope.bookingDetails.pickupAddress !== 'Select a location'){
                     $rootScope.show();
                    $scope.bookDetailsModal.hide();

                    var lat = $rootScope.ConUsers.user.addressLat.toFixed(4);
                    var long = $rootScope.ConUsers.user.addressLong.toFixed(4);
                    if ($rootScope.currentLocationLat === lat && $rootScope.currentLocationLng === long) {
                        $rootScope.default = true;
                        $rootScope.bookingDetails.pickupAddress = null;
                        $rootScope.bookingDetails.landmark = null;
                        $rootScope.bookingDetails.pickupAddress = $rootScope.ConUsers.user.addressLine2;
                        $rootScope.bookingDetails.landmark = $rootScope.ConUsers.user.address;
                    } else {
                        $rootScope.default = false;
                        $rootScope.bookingDetails.pickupAddress = $rootScope.bookingDetails.pickupAddress;
                        //$rootScope.landmark = $scope.landMark;
                        $rootScope.bookingDetails.landmark = $rootScope.bookingDetails.landmark;
                    }

                    $scope.landmarkModel.show();

                    $rootScope.hide();   
                }else{
                    $scope.openLandmarkModel();

                    // $cordovaDialogs.alert('Please wait, fetching location.', 'Alert');
                }
                    
                }
                $scope.openRptDateModal = function() {
                    //$scope.releivingDatepicker = null;
                    if ($rootScope.bookingDetails.routeType === 'One Way') {
                        $rootScope.headerTitle = 'Book My Driver';
                        $rootScope.footerTitle = 'Book My Driver';
                    }

                    $rootScope.show();
                    $scope.bookDetailsModal.hide();
                    if ($rootScope.bookingDetails.rptHour === null) {
                        getReportingTime();
                    }



                    $scope.reportingDatepicker.date = $rootScope.bookingDetails.rptDate;
                    $scope.rptDateModal.show();
                    $rootScope.hide();
                };


                $scope.closeRptDateModal = function() {
                    $rootScope.enableText = true;
                    $rootScope.enableText1 = false;
                    $scope.reportingTimeValidationFlag = true;
                    $scope.resetBookingDetails();
                   // $scope.openLandmarkModel();
                    $scope.rptDateModal.hide();
                    //if (angular.isDefined($rootScope.map)) {
                    //  $rootScope.map.setClickable(true);

                };

                $scope.closeLandmarkModal = function() {
                    $scope.inValidAddress = null;
                    $scope.resetBookingDetails();
                    $scope.landmarkModel.hide();
                    if (angular.isDefined($rootScope.map)) {
                        $rootScope.map.setClickable(true);
                    }

                };
                $scope.validateLandmarkModal = function(landmark) {

                    if (angular.isUndefined(landmark)) {

                        $scope.inValidAddress = 'LandMark is compulsory';
                    } else if (landmark === '' || landmark === null) {

                        $scope.inValidAddress = 'Landmark can not be blank';

                    } else {

                            if(angular.isUndefined($rootScope.bookingDetails.pickupAddress) || $rootScope.bookingDetails.pickupAddress === '' || $rootScope.bookingDetails.pickupAddress === null){
                             $scope.inValidAddress2 = 'Pickup address is compulsory';
                        }else{
                            $scope.inValidAddress2 = null;

                        $scope.inValidAddress = null;
                        $scope.landmarkModel.hide();
                        $scope.openRptDateModal();
                    }
                    }

                };



                $scope.validateRptDate = function() {
                    $scope.repInvalidTimeFlag = true;
                    $scope.reportingTimeValidationFlag = true;
                    var d = new Date();
                    var curr_hour = d.getHours();
                    var tempRepHour = null;
                    if ($rootScope.bookingDetails.rptTime.value === 'PM') // rep time pm 
                    {

                        if ($rootScope.bookingDetails.rptHour.value == 12) {
                            tempRepHour = $rootScope.bookingDetails.rptHour.value;
                        } else {
                            tempRepHour = $rootScope.bookingDetails.rptHour.value + 12;
                        }

                    } else {
                        if ($rootScope.bookingDetails.rptHour.value == 12) {
                            tempRepHour = 0;
                        } else {
                            tempRepHour = $rootScope.bookingDetails.rptHour.value;
                        }
                    }
                    $rootScope.reportingTimeHour = tempRepHour;
                    var tempRepMinutes = $rootScope.bookingDetails.rptMinute.value;
                    var curr_Minites = d.getMinutes();

                    var currTimeInMinites = (curr_hour * 60) + curr_Minites;
                    var repTimeInMinites = (tempRepHour * 60) + parseInt(tempRepMinutes);
                    var bookingDate = $scope.reportingDatepicker.date;

                    if (d.toDateString() === bookingDate.toDateString()) {
                        if (curr_hour > tempRepHour) {
                            $scope.repInvalidTimeFlag = false;
                            /* $scope.reportingTimeValidationFlag = false;*/

                        } else if (repTimeInMinites - currTimeInMinites < 120) {
                            /*$scope.reportingTimeValidationFlag = true;*/
                            $scope.repInvalidTimeFlag = false;

                        } else {

                            $scope.repInvalidTimeFlag = true;

                        }

                    } else {
                        /*$scope.reportingTimeValidationFlag = true;*/
                        $scope.repInvalidTimeFlag = true;

                    }

                    if ($scope.repInvalidTimeFlag === true) {
                        $scope.openBookingDetailsModal();
                    }
                };

                $scope.openBookingDetailsModal = function() {
                    if ($rootScope.bookingDetails.routeType === 'One Way') {
                        $rootScope.headerTitle = 'Select Drop Location';
                        $rootScope.footerTitle = 'Set As Drop Location';
                    }

                    $rootScope.show();
                    $scope.showBookingConfirmationFlag = true;
                    $scope.rptDateModal.hide();
                    $scope.relTimeModal.hide();
                    $rootScope.bookingDetails.rptDate = $scope.reportingDatepicker.date;
                    $scope.bookDetailsModal.show();
                    $rootScope.hide();
                };

                $scope.openRelTimeModal = function() {
                    //$rootScope.bookingDetails.relTime =null;
                    //$scope.releivingDatepicker = null;
                    //$rootScope.bookingDetails.relHour = null;
                    //$rootScope.bookingDetails.relMinute = null;
                    $rootScope.headerTitle = 'Book My Driver';
                    $rootScope.footerTitle = 'Book My Driver';
                    if ($rootScope.bookingDetails.routeType == 'One Way' && $rootScope.bookingDetails.dropAddress === null) //Journey type one way and drop location is not selected
                    {
                        $scope.selectDropLocationFlag = false;
                    } else {
                        $scope.selectDropLocationFlag = true;
                        $scope.bookDetailsModal.hide();
                        if ($rootScope.bookingDetails.relHour === null) {
                            getReleivingTime();
                        }
                        $scope.relTimeModal.show();

                    }
                };

                $scope.openRelDateModal = function() {
                    /* $rootScope.bookingDetails.relTime =null;
                     $rootScope.bookingDetails.relHour = null;
                    $rootScope.bookingDetails.relMinute = null;*/
                    //$scope.releivingDatepicker = null;
                    $rootScope.headerTitle = 'Book My Driver';
                    $rootScope.footerTitle = 'Book My Driver';
                    if ($rootScope.bookingDetails.outstationCity !== 'Select Outstation City' && $rootScope.bookingDetails.outstationCity != null) { //City selected

                        $scope.selectedCityFlag = true;
                        if ($rootScope.bookingDetails.routeType == 'One Way' && $rootScope.bookingDetails.dropAddress === null) //Journey type one way and drop location is not selected
                        {
                            $scope.selectDropLocationFlag = false;

                        } else {
                            if ($rootScope.bookingDetails.routeType == 'One Way' && $rootScope.bookingDetails.dutyType != 'Local') {
                                         $scope.bookDetailsModal.hide();
                                        $scope.relDateModal.show();
                                    
                            } else {
                                $scope.selectDropLocationFlag = true;

                                $scope.bookDetailsModal.hide();
                                if ($rootScope.bookingDetails.relHour === null) {
                                    getReleivingDefaultTime();
                                }
                                $scope.relDateModal.show();
                            }

                        }
                    } else {

                        $scope.selectedCityFlag = false;
                        if ($rootScope.bookingDetails.routeType == 'One Way' && $rootScope.bookingDetails.dropAddress === 'Select Drop Location') //Journey type one way and drop location is not selected
                        {
                            $scope.selectDropLocationFlag = false;
                        } else {
                            $scope.selectDropLocationFlag = true;
                        }
                    }

                };
                $scope.back = function() {
                    $scope.bookConfirmModal.hide();
                };

                $scope.openPaymentModeModal = function() {

                    if ($rootScope.bookingDetails.dutyType != 'Local') {
                        if (($scope.releivingDatepicker.date === null) && ($rootScope.bookingDetails.relTime === null)) {
                            $scope.dateerror = 'Select relieving date';
                            $scope.timeerror = 'Select relieving time';
                        } else if ($scope.releivingDatepicker.date === null) {
                            $scope.dateerror = 'Select relieving date';
                            $scope.timeerror = null;
                        } else if ($rootScope.bookingDetails.relTime === null) {
                            $scope.timeerror = 'Select relieving time';
                            $scope.dateerror = null;
                        } else {
                            $scope.timeerror = null;
                            $scope.dateerror = null;
                            var relDate1 = $scope.releivingDatepicker.date;
                            var repDate1 = $rootScope.bookingDetails.rptDate;
                            if (relDate1.toDateString() === repDate1.toDateString()) { //if outstation and same dates
                                var tempRepHour = null;
                                var tempRelHour = null;
                                if ($rootScope.bookingDetails.rptTime.value === 'PM') // rep time pm 
                                {
                                    if ($rootScope.bookingDetails.rptHour.value == 12) {
                                        tempRepHour = 12;
                                    } else {
                                        tempRepHour = $rootScope.bookingDetails.rptHour.value + 12

                                    }
                                } else {
                                    if ($rootScope.bookingDetails.rptHour.value == 12) {
                                        tempRepHour = 0;
                                    } {
                                        tempRepHour = $rootScope.bookingDetails.rptHour.value;
                                    }
                                }


                                if ($rootScope.bookingDetails.relTime.value === 'PM') // rep time pm 
                                {
                                    if ($rootScope.bookingDetails.relHour.value == 12) {
                                        tempRelHour = 12;
                                    } else {
                                        tempRelHour = $rootScope.bookingDetails.relHour.value + 12

                                    }
                                } else {
                                    if ($rootScope.bookingDetails.relHour.value == 12) {
                                        tempRelHour = 0;
                                    } else {
                                        tempRelHour = $rootScope.bookingDetails.relHour.value;
                                    }
                                }
                                var tempRelDate = new Date(relDate1);
                                var tempRepDate = new Date(repDate1);
                                tempRelDate.setHours(tempRepHour, $rootScope.bookingDetails.relMinute.value, 0);
                                tempRepDate.setHours(tempRelHour, $rootScope.bookingDetails.rptMinute.value, 0);

                                $rootScope.dutyHour = Math.abs(tempRelDate.getTime() - tempRepDate.getTime()) / 36e5;




                                var tempRepMinutes = $rootScope.bookingDetails.rptMinute.value;

                                var relTimeInMinites = (tempRelHour * 60) + parseInt($rootScope.bookingDetails.relMinute.value);
                                var repTimeInMinites = (tempRepHour * 60) + parseInt(tempRepMinutes);

                                if (relTimeInMinites - repTimeInMinites < 0) {
                                    $scope.showBookingConfirmationFlag = false;
                                } else {
                                    $scope.showBookingConfirmationFlag = true;
                                    $scope.relTimeModal.hide();
                                    $scope.relDateModal.hide();
                                    $rootScope.bookingDetails.relDate = $scope.releivingDatepicker.date;
                                    addReturnTravelTime();
                                    $scope.paymentModeModal.show();


                                }
                            } else if (relDate1 < repDate1) {
                                $scope.showBookingConfirmationFlag = false;

                            } else {
                                $scope.showBookingConfirmationFlag = true;
                                $scope.relTimeModal.hide
                                $scope.relDateModal.hide();
                                $rootScope.bookingDetails.relDate = $scope.releivingDatepicker.date;
                                addReturnTravelTime();
                                $scope.paymentModeModal.show();

                            }
                        }
                    } else {
                        if ($rootScope.bookingDetails.relHour === null && $rootScope.bookingDetails.relMinute === null) {
                            $scope.invalidDutyHours = 'Please select estimated duty hours and minutes.';
                        } else if ($rootScope.bookingDetails.relHour === null) {
                            $scope.invalidDutyHours = 'Please select estimated duty hours.';
                        } else if ($rootScope.bookingDetails.relMinute === null) {
                            $scope.invalidDutyHours = 'Please select estimated duty minutes.';
                        } else {
                            $scope.invalidDutyHours = null;
                            $scope.closeReleivingTimeModal();
                            $scope.showBookingConfirmationFlag = true;
                            $scope.paymentModeModal.show();
                        }
                    }

                };






                function addReturnTravelTime() {
                    if ($rootScope.bookingDetails.routeType == 'One Way') {
                        if ($rootScope.bookingDetails.dutyType == 'Local') {

                        } else {
                            Bookings.calculateDistanceByLatLong({
                                    lat1: $rootScope.bookingDetails.pickupLat,
                                    long1: $rootScope.bookingDetails.pickupLng,
                                    lat2: $rootScope.bookingDetails.dropLat,
                                    long2: $rootScope.bookingDetails.dropLng
                                },
                                function(response) {

                                    console.log('distance response' + JSON.stringify(response));
                                    var returnTravelHour = 0;
                                    var returnTravelMinute = 0;
                                    var returnTravelTime = response.rows[0].elements[0].distance.value;
                                    returnTravelTime = Math.round(returnTravelTime);
                                    returnTravelTime = (returnTravelTime / 35000);
                                    returnTravelTime = returnTravelTime.toFixed(2);


                                    var arr = returnTravelTime.split('.');
                                    returnTravelHour = parseInt(arr[0]);
                                    returnTravelMinute = parseInt(arr[1]);
                                    if (returnTravelMinute < 10) {
                                        returnTravelMinute = '0' + returnTravelMinute;
                                    }
                                    returnTravelMinute = returnTravelMinute * 0.6;
                                    returnTravelMinute = Math.round(returnTravelMinute);
                                    if ((angular.isDefined($rootScope.returnTravelHour)) || (angular.isDefined($rootScope.returnTravelMinute))) {
                                        $rootScope.returnTravelHour = undefined;
                                        $rootScope.returnTravelMinute = undefined;
                                    }
                                    $rootScope.returnTravelHour = returnTravelHour;
                                    $rootScope.returnTravelMinute = returnTravelMinute;
                                    /*returnTravelMinute = (returnTravelMinute * 60).toFixed(0);
                                    if (returnTravelMinute > 30) {
                                        returnTravelHour = parseInt(returnTravelHour) + 1;
                                    }
                                    returnTravelMinute = 0;
                                    returnTravelMinute = parseInt(returnTravelMinute / 15) * 15;
                                     
                                    $scope.relHourBeforAddReturnTT = $rootScope.bookingDetails.relHour.value;
                                    $scope.relMinuteBeforAddReturnTT = $rootScope.bookingDetails.relMinute.value;
                                    $scope.relTimeBeforAddReturnTT = $rootScope.bookingDetails.relTime.value;
                                    $scope.relDateBeforAddReturnTT = $rootScope.bookingDetails.relDate;
                                  
                                    var tempRelHour = $rootScope.bookingDetails.relHour.value;
                                    var tempRelMinute = $rootScope.bookingDetails.relMinute.value;
                                    var dayIncreament;
                                    if ($rootScope.bookingDetails.relTime.value == 'PM') {
                                        tempRelHour = tempRelHour + 12;
                                    }
                                    tempRelHour = tempRelHour + returnTravelHour;
                                    tempRelMinute = parseInt(tempRelMinute) + parseInt(returnTravelMinute);
                                    if (tempRelMinute > 60) {
                                        $scope.relMinuteBeforAddReturnTT = parseInt(tempRelMinute) - 60;
                                        tempRelHour = tempRelHour + 1;
                                    } else {
                                        $scope.relMinuteBeforAddReturnTT = tempRelMinute;
                                    }
                                    dayIncreament = parseInt(tempRelHour / 24);
                                    $scope.relHourBeforAddReturnTT = tempRelHour - (24 * parseInt(tempRelHour / 24));
                                    
                                    if ($scope.relHourBeforAddReturnTT > 12) {
                                        $scope.relHourBeforAddReturnTT = $scope.relHourBeforAddReturnTT - 12;
                                        $scope.relTimeBeforAddReturnTT = 'PM';
                                    } else if ($scope.relHourBeforAddReturnTT == 12) {
                                        $scope.relTimeBeforAddReturnTT = 'PM';
                                    } else {
                                        $scope.relTimeBeforAddReturnTT = 'AM';
                                    }
                                    var increamentedDate = new Date($rootScope.bookingDetails.relDate);
                                    increamentedDate.setDate(increamentedDate.getDate() + dayIncreament);
                                    $scope.relDateBeforAddReturnTT = increamentedDate;
                                    $rootScope.bookingDetails.relDate = $scope.relDateBeforAddReturnTT;
                                    var hourIndex = $scope.relHourBeforAddReturnTT;
                                    if (parseInt(hourIndex) === 0) {
                                        $rootScope.bookingDetails.relHour = ENV.hourArray[ENV.hourArray.length - 1];
                                    } else {
                                        $rootScope.bookingDetails.relHour = ENV.hourArray[hourIndex - 1];
                                    }
                                    var minIndex = 0;
                                    minIndex = parseInt(((parseInt($scope.relMinuteBeforAddReturnTT) + 15) / 15) - 1);
                                    if (minIndex == 4) {
                                        minIndex = 0;
                                    }
                                    
                                    $rootScope.bookingDetails.relMinute = ENV.minuteArray[minIndex];
                                    if ($scope.relTimeBeforAddReturnTT == 'AM') {
                                        $rootScope.bookingDetails.relTime = ENV.timeArray[0];
                                    } else {
                                        $rootScope.bookingDetails.relTime = ENV.timeArray[1];
                                    }*/

                                    validationForConfirmPage();
                                },
                                function(error) {
                                    $cordovaDialogs.alert('Please check internet connection and try again later', 'Alert');

                                    $state.go('newBooking');
                                });
                        }
                    }
                }


                function validationForConfirmPage() {

                }


                $scope.closePaymentModeModal = function() {
                    $scope.paymentModeModal.hide();
                };

                $scope.setReportingHour = function(index) {
                    $rootScope.bookingDetails.rptHour = $rootScope.hourArray[index];
                };

                $scope.setReportingMinute = function(index) {
                    $rootScope.bookingDetails.rptMinute = $rootScope.minuteArray[index];
                };

                $scope.setReportingTime = function(index) {
                    $rootScope.bookingDetails.rptTime = $rootScope.timeArray[index];
                };

                $scope.setReleivingHour = function(index) {
                    $rootScope.bookingDetails.relHour = $rootScope.hourArray[index];

                };

                $scope.setReleivingMinute = function(index) {
                    $rootScope.bookingDetails.relMinute = $rootScope.minuteArray[index];

                };

                $scope.setReleivingTime = function(index) {
                    $rootScope.bookingDetails.relTime = $rootScope.timeArray[index];
                };

                $scope.setOutStationCity = function(selectedCity) {
                    if(angular.isUndefined(selectedCity) || selectedCity === null || selectedCity === ''){
                        $scope.invalidCity = 'Please mention city';
                    }else{
                        $scope.invalidCity = null;
                        $scope.selectedCityFlag = true;
                        $rootScope.bookingDetails.outstationCity = selectedCity;
                        
                                  $scope.outCityModal.hide();
                    }

                    
                                
                };


                function getReportingTime() {

                    var d1 = new Date();

                    var d2 = new Date();
                    d2.setHours(d2.getHours() + 2, d2.getMinutes(), 0, 0);

                    var time = d2.toLocaleTimeString().replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, '$1$3')
                    $scope.validReportingTime = time;

                    var curr_hour = d1.getHours();
                    if (curr_hour >= 6 && curr_hour < 22) {

                        d1.setHours(curr_hour + 2, d1.getMinutes() + 15, 0, 0);
                        $rootScope.bookingDetails.rptHour = curr_hour + 2;

                        var minIndex = parseInt((d1.getMinutes() + 15) / 15) - 1;
                        if (minIndex == -1) {
                            minIndex = 0;
                        }

                        $rootScope.bookingDetails.rptMinute = ENV.minuteArray[minIndex];
                    } else {
                        d1.setDate(d1.getDate() + 1);
                        d1.setHours(6, 0, 0, 0);
                        $rootScope.bookingDetails.rptHour = 6;
                        $rootScope.bookingDetails.rptMinute = ENV.minuteArray[0];

                    }

                    if (parseInt(d1.getHours()) < 12) {
                        $rootScope.bookingDetails.rptTime = ENV.timeArray[0];

                    } else {
                        $rootScope.bookingDetails.rptTime = ENV.timeArray[1];

                    }

                    var hourIndex = parseInt(d1.getHours());

                    if (hourIndex > 12) {
                        hourIndex -= 12;
                    } else if (hourIndex === 12) {
                        hourIndex = 0;
                    }

                    if (hourIndex === 0) {
                        $rootScope.bookingDetails.rptHour = ENV.hourArray[ENV.hourArray.length - 1];

                    } else {
                        $rootScope.bookingDetails.rptHour = ENV.hourArray[hourIndex - 1];
                    }

                    $scope.rptTimeFlag = 1;
                }

                function getReleivingTime() {
                    var d1 = new Date();
                    $rootScope.bookingDetails.relHour = null; /*ENV.hourArray[3];*/
                    $rootScope.bookingDetails.relMinute = null; /* ENV.minuteArray[0];*/

                    $scope.relTimeFlag = 1;
                }

                function getReleivingDefaultTime() {
                    var d1 = new Date();

                    var tempRepHour = null;
                    if ($rootScope.bookingDetails.rptTime.value === 'PM') // rep time pm 
                    {
                        if ($rootScope.bookingDetails.rptHour.value == 12) {
                            tempRepHour = $rootScope.bookingDetails.rptHour.value;

                        } else {
                            tempRepHour = $rootScope.bookingDetails.rptHour.value + 12;
                        }


                    } else {
                        if ($rootScope.bookingDetails.rptHour.value == 12) {
                            tempRepHour = 0;
                        } else {
                            tempRepHour = $rootScope.bookingDetails.rptHour.value;

                        }

                    }

                    var minIndex = 0;
                    /*  if ($rootScope.bookingDetails.dutyType === 'Outstation') {
                        tempRepHour = tempRepHour + 12;
                        
                        minIndex = parseInt(((parseInt($rootScope.bookingDetails.rptMinute.value) + 15) / 15) - 1);
                        if (tempRepHour >= 24) {
                            var increamentedDate = new Date($rootScope.bookingDetails.rptDate);
                            increamentedDate.setDate(increamentedDate.getDate() + 1);
                            $scope.releivingDatepicker.date = increamentedDate;
                            tempRepHour = tempRepHour - 24;
                        } else {
                            $scope.releivingDatepicker.date = $rootScope.bookingDetails.rptDate;

                        }


                        $rootScope.bookingDetails.relMinute = ENV.minuteArray[minIndex];

 
                        if (parseInt(tempRepHour) < 12) {
                            $rootScope.bookingDetails.relTime = ENV.timeArray[0];

                        } else {
                            $rootScope.bookingDetails.relTime = ENV.timeArray[1];

                        }

                        var hourIndex = tempRepHour;

                        if (hourIndex > 12) {
                            hourIndex -= 12;
                        }

                        if (hourIndex === 0) {
                            $rootScope.bookingDetails.relHour = ENV.hourArray[ENV.hourArray.length - 1];

                        } else {
                            $rootScope.bookingDetails.relHour = ENV.hourArray[hourIndex - 1];
                        }

                    }*/
                }
                $scope.setCarType = function(index) {

                    $rootScope.bookingDetails.carType = $rootScope.carTypeArray[index].value;
                };
                 $scope.setOperationCity = function(index) {

                    $rootScope.operationCity = $rootScope.operationCities[index];
                    console.log($rootScope.operationCities[index]);
                    Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCities[index]
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;
                                console.log(s);
                        },function(r){
                    });
                };
                $scope.setPaymentMode = function(index) {

                    $rootScope.bookingDetails.paymentMode = $rootScope.paymentModeArray[index].value;

                };

                $scope.setDutyType = function(index) {
                    if($rootScope.bookingDetails.dutyType === 'Local'){
                        $rootScope.bookingDetails.outstationCity = null;
                       // $rootScope.outStationCity = null;
                    }

                    $rootScope.bookingDetails.dutyType = $rootScope.dutyTypeArray[index].value;
                };


                $scope.setRouteType = function(index) {
                    $rootScope.bookingDetails.routeType = $rootScope.journeyTypeArray[index].value;
                };

                $scope.openCarTypeModal = function() {

                    $scope.relTimeModal.hide();
                    $scope.dutyTypeModal.hide();
                    $scope.carTypeModal.show();
                };

                $scope.openDutyTypeModal = function() {

                    $scope.carTypeModal.hide();
                    $scope.routeTypeModal.hide();
                    $scope.dutyTypeModal.show();
                };

                $scope.openRouteTypeModal = function() {

                    $scope.dutyTypeModal.hide();
                    $scope.routeTypeModal.show();
                };




                $scope.selectRouteType = function(routeType) {
                    $rootScope.bookingDetails.routeType = routeType;
                };

                $scope.selectCarType = function(carType) {
                    $rootScope.bookingDetails.carType = carType;
                };

                $scope.selectDutyType = function(dutyType) {
                    $rootScope.bookingDetails.dutyType = dutyType;
                };

                $scope.submitRouteType = function() {
                    if ($rootScope.bookingDetails.routeType === 'One Way') {
                        $scope.oneWay();
                    } else {
                        $scope.roundTrip();
                    }
                };

                $scope.roundTrip = function() {

                    $rootScope.bookingDetails.dropAddress = $rootScope.bookingDetails.pickupAddress;
                    $scope.showBookingConfirmation();
                };

                $scope.oneWay = function() {
                    $scope.bookDetailsModal.hide();
                    if (angular.isDefined($rootScope.map)) {
                        $rootScope.map.setClickable(true);
                    }


                    if ($rootScope.bookingDetails.dutyType === 'Outstation') {
                       
                    }


                    $rootScope.locationFlag = 'drop';
                  //  $rootScope.headerTitle = 'Select Drop Location';
                    $rootScope.footerTitle = 'Set As Drop Location';


                };

                $scope.openOutstationCityModal = function() {

                        $rootScope.bookingDetails.outstationCity = null;
                        $rootScope.outStationCity = null;
                
                    $scope.outCityModal.show();
                };


                $scope.closeOutStationCityModal = function() {

                    $scope.outCityModal.hide();
                };


                $scope.showBookingConfirmation = function() {

                    $scope.closePaymentModeModal();
                    $rootScope.paymentModeSeleted = true;
                    $scope.calculateFare();
                    $scope.bookConfirmModal.show();
                    // $state.go('confirmBooking');
                    $rootScope.hide();


                };
                $scope.localOneway = function() {
                    Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;

                                console.log(s);
                                 RateCard.find({
                            filter: {
                                where: {
                                    type:'Customer',
                                    operationCityId: $rootScope.operationCityId
                                }
                            }
                        },
                        function(rateCardsuc1) {

                            $rootScope.rateCardDetail1 = $sce.trustAsHtml(rateCardsuc1[0].rateCardHtml);

                        },
                        function(ratecarderr1) {

                        });

                                
                        },function(r){
                    });
                    
                }
                $scope.localRoundTrip = function() {
                    Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;

                                console.log(s);
                    RateCard.find({
                            filter: {
                                where: {
                                    type:'Customer',
                                    operationCityId: $rootScope.operationCityId
                                }
                            }
                        },
                        function(rateCardsuc2) {

                            $rootScope.rateCardDetail2 = $sce.trustAsHtml(rateCardsuc2[0].rateCardHtml);

                        },
                        function(ratecarderr2) {

                        });
                    },function(r){
                    });

                }

                $scope.outstationOneway = function() {
                    Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;

                                console.log(s);
                    RateCard.find({
                            filter: {
                                where: {
                                    type:'Customer',
                                    operationCityId: $rootScope.operationCityId
                                }
                            }
                        },
                        function(rateCardsuc3) {

                            $rootScope.rateCardDetail3 = $sce.trustAsHtml(rateCardsuc3[0].rateCardHtml);

                        },
                        function(ratecarderr3) {

                        });
                    },function(r){
                    });
                    };

                $scope.outstationRoundTrip = function() {
                    Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;

                                console.log(s);
                    RateCard.find({
                            filter: {
                                where: {
                                    type:'Customer',
                                    operationCityId: $rootScope.operationCityId
                                }
                            }
                        },
                        function(rateCardsuc4) {

                            $rootScope.rateCardDetail4 = $sce.trustAsHtml(rateCardsuc4[0].rateCardHtml);

                        },
                        function(ratecarderr4) {


                        });
                    },function(r){
                    });

                }

                


                $scope.showConfirmBookingRateCardAtLocalRoundTrip = function() {
                    $scope.localRoundTrip();
                    //$scope.bookConfirmModal.hide();
                    $scope.confirmBookingRateCardLocalRoundTripModal.show();

                };



                $scope.backConfirmBookingRateCardAtLocalRoundTrip = function() {

                    $scope.confirmBookingRateCardLocalRoundTripModal.hide();
                    $scope.bookConfirmModal.show();
                    //$state.go('confirmBooking');

                };
                $scope.showConfirmBookingRateCardLocalOneWay = function() {
                    $scope.localOneway();
                    //$scope.bookConfirmModal.hide();
                    $scope.confirmBookingRateCardLocalOneWayModal.show();

                };
                $scope.backConfirmBookingRateCardAtLocalOneWay = function() {

                    $scope.confirmBookingRateCardLocalOneWayModal.hide();
                    $scope.bookConfirmModal.show();
                    // $state.go('confirmBooking');

                };
                $scope.showConfirmBookingRateCardOutstationRoundTrip = function() {
                    $scope.outstationRoundTrip();
                    // $scope.bookConfirmModal.hide();
                    $scope.confirmBookingRateCardOutstationRoundTripModal.show();

                };
                $scope.backConfirmBookingRateCardAtOutstationRoundTrip = function() {

                    $scope.confirmBookingRateCardOutstationRoundTripModal.hide();
                    $scope.bookConfirmModal.show();
                    //$state.go('confirmBooking');

                };
                $scope.showConfirmBookingRateCardOutstationOneWay = function() {
                    $scope.outstationOneway();
                    // $scope.bookConfirmModal.hide();
                    $scope.confirmBookingRateCardOutstationOneWayModal.show();

                };
                $scope.backConfirmBookingRateCardAtOutstationOneWay = function() {

                    $scope.confirmBookingRateCardOutstationOneWayModal.hide();
                    $scope.bookConfirmModal.show();
                    //$state.go('confirmBooking');

                };


                $scope.calculateFare = function() {

                    $scope.loadingIndicator = $ionicLoading.show({
                        template: '<ion-spinner icon="spiral"></ion-spinner>'

                    });
                    var rptDate = $rootScope.bookingDetails.rptDate;
                    var relDate = $rootScope.bookingDetails.relDate;

                    if ($rootScope.bookingDetails.rptHour.value === 12 && $rootScope.bookingDetails.rptTime.value === 'AM') {
                        rptDate.setHours(0, parseInt($rootScope.bookingDetails.rptMinute.value));
                    } else if ($rootScope.bookingDetails.rptHour.value < 12 && $rootScope.bookingDetails.rptTime.value === 'PM') {
                        rptDate.setHours(($rootScope.bookingDetails.rptHour.value + 12), parseInt($rootScope.bookingDetails.rptMinute.value));
                    } else {
                        rptDate.setHours($rootScope.bookingDetails.rptHour.value, parseInt($rootScope.bookingDetails.rptMinute.value));
                    }

                    var d1 = new Date(rptDate);
                    var hours, minutes;
                    var date, month, year;
                    var actualReportingDate, actualReportingTime, actualReleivingDate, actualReleivingTime;
                    var isOutstation = false;
                    var isRoundTrip = false;

                    if ($rootScope.bookingDetails.dutyType === 'Outstation') {
                        isOutstation = true;
                    }

                    if ($rootScope.bookingDetails.routeType === 'Round Trip') {
                        isRoundTrip = true;
                        $rootScope.bookingDetails.dropAddress = $rootScope.bookingDetails.pickupAddress;
                        $rootScope.bookingDetails.dropLat = $rootScope.bookingDetails.pickupLat;
                        $rootScope.bookingDetails.dropLng = $rootScope.bookingDetails.pickupLng;
                    }

                    date = rptDate.getDate();
                    if (date < 10) {
                        date = '0' + date;
                    }

                    month = rptDate.getMonth();
                    month = month + 1;
                    if (month < 10) {
                        month = '0' + month;
                    }

                    year = rptDate.getFullYear();

                    actualReportingDate = year + '-' + month + '-' + date;

                    actualReportingTime = $rootScope.bookingDetails.rptHour.value + ':' + $rootScope.bookingDetails.rptMinute.value + ' ' + $rootScope.bookingDetails.rptTime.value;

                    if (isOutstation === false) {
                        hours = d1.getHours();
                        minutes = d1.getMinutes();
                        d1.setHours((hours + parseInt($rootScope.bookingDetails.relHour.value)), (minutes + parseInt($rootScope.bookingDetails.relMinute.value)), 0, 0);
                        relDate = d1;
                        hours = d1.getHours();
                        minutes = d1.getMinutes();

                        actualReleivingTime = hours + ':' + minutes;
                    } else {
                        actualReleivingTime = $rootScope.bookingDetails.relHour.value + ':' + $rootScope.bookingDetails.relMinute.value + ' ' + $rootScope.bookingDetails.relTime.value;
                    }

                    date = relDate.getDate();
                    if (date < 10) {
                        date = '0' + date;
                    }

                    month = relDate.getMonth();
                    month = month + 1;
                    if (month < 10) {
                        month = '0' + month;
                    }

                    year = relDate.getFullYear();

                    actualReleivingDate = year + '-' + month + '-' + date;
                    $rootScope.bookingDetails.relDate = actualReleivingDate;

                    $rootScope.dropTimeHour = actualReleivingTime.split(':')[0];

                    if(angular.isDefined($rootScope.operationCityId) && $rootScope.operationCityId != null && $rootScope.operationCityId != ' ' ){
                        if (isRoundTrip === false && isOutstation === true) {
                            Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;
                                console.log(s);
                        FareMatrix.calculateFare({
                                carType: 'OD',
                                isRoundTrip: isRoundTrip,
                                isOutstation: isOutstation,
                                actualReportingDate: actualReportingDate,
                                actualReportingTime: actualReportingTime,
                                actualReleivingDate: actualReleivingDate,
                                actualReleivingTime: actualReleivingTime,
                                pickupLat: 18.5240566,//$rootScope.bookingDetails.pickupLat,
                                pickupLng: 73.8646945,//$rootScope.bookingDetails.pickupLng,
                                dropLat:18.5240566,// $rootScope.bookingDetails.dropLat,
                                dropLng: 73.8646945,//$rootScope.bookingDetails.dropLng
                                operationCityId:$rootScope.operationCityId
                            },
                            function(response) {
                                console.log('log : ' + JSON.stringify(response));

                                $scope.bookingFare = [];
                                $scope.invoiceChargeDetail = response;

                                var totalAmount = 0;
                                var tempInvoiceHeadId = 0;
                                var tempInvoiceHeadName = '';
                                var headAmount = 0;

                                for (var i = 0; i < response.length; i++) {
                                    if (response[i].invoiceHeadId !== tempInvoiceHeadId) {
                                        if (i !== 0) {
                                            $scope.bookingFare.push({
                                                invoiceHeadName: tempInvoiceHeadName,
                                                amount: headAmount
                                            });
                                        }
                                        headAmount = 0;
                                        headAmount = headAmount + response[i].amount;
                                        tempInvoiceHeadId = response[i].invoiceHeadId;
                                        tempInvoiceHeadName = response[i].invoiceHeadName;
                                    } else {
                                        headAmount = headAmount + response[i].amount;
                                    }
                                    totalAmount = totalAmount + response[i].amount;
                                }

                                $scope.bookingFare.push({
                                    invoiceHeadName: tempInvoiceHeadName,
                                    amount: headAmount
                                });

                                $scope.totalAmount = totalAmount;

                                $ionicLoading.hide();
                            },
                            function(error) {
                                $cordovaDialogs.alert('Please check internet connection and try again later.', 'Alert');
                                $state.go('newBooking');
                                $ionicLoading.hide();

                            });
                         },function(r){
                    });


                    } else {
                        Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;
                                console.log(s);

                        FareMatrix.calculateFare({
                                carType: $rootScope.bookingDetails.carType.substr(0, 1),
                                isRoundTrip: isRoundTrip,
                                isOutstation: isOutstation,
                                actualReportingDate: actualReportingDate,
                                actualReportingTime: actualReportingTime,
                                actualReleivingDate: actualReleivingDate,
                                actualReleivingTime: actualReleivingTime,
                                pickupLat: 18.5240566,//$rootScope.bookingDetails.pickupLat,
                                pickupLng: 73.8646945,//$rootScope.bookingDetails.pickupLng,
                                dropLat:18.5240566,// $rootScope.bookingDetails.dropLat,
                                dropLng: 73.8646945,
                                operationCityId:$rootScope.operationCityId
                            },
                            function(response) {


                                $scope.bookingFare = [];
                                $scope.invoiceChargeDetail = response;

                                var totalAmount = 0;
                                var tempInvoiceHeadId = 0;
                                var tempInvoiceHeadName = '';
                                var headAmount = 0;

                                for (var i = 0; i < response.length; i++) {
                                    if (response[i].invoiceHeadId !== tempInvoiceHeadId) {
                                        if (i !== 0) {
                                            $scope.bookingFare.push({
                                                invoiceHeadName: tempInvoiceHeadName,
                                                amount: headAmount
                                            });
                                        }
                                        headAmount = 0;
                                        headAmount = headAmount + response[i].amount;
                                        tempInvoiceHeadId = response[i].invoiceHeadId;
                                        tempInvoiceHeadName = response[i].invoiceHeadName;
                                    } else {
                                        headAmount = headAmount + response[i].amount;
                                    }
                                    totalAmount = totalAmount + response[i].amount;
                                }

                                $scope.bookingFare.push({
                                    invoiceHeadName: tempInvoiceHeadName,
                                    amount: headAmount
                                });

                                $scope.totalAmount = totalAmount;

                                $ionicLoading.hide();
                            },
                            function(error) {
                                $cordovaDialogs.alert('Please check internet connection and try again later.', 'Alert');
                                $state.go('newBooking');
                                $ionicLoading.hide();

                            });
                         },function(r){
                    });
                    }
                    }else{
                        Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;
                                console.log(s);
                                if (isRoundTrip === false && isOutstation === true) {
                        FareMatrix.calculateFare({
                                carType: 'OD',
                                isRoundTrip: isRoundTrip,
                                isOutstation: isOutstation,
                                actualReportingDate: actualReportingDate,
                                actualReportingTime: actualReportingTime,
                                actualReleivingDate: actualReleivingDate,
                                actualReleivingTime: actualReleivingTime,
                                pickupLat: 18.5240566,//$rootScope.bookingDetails.pickupLat,
                                pickupLng: 73.8646945,//$rootScope.bookingDetails.pickupLng,
                                dropLat:18.5240566,// $rootScope.bookingDetails.dropLat,
                                dropLng: 73.8646945,//$rootScope.bookingDetails.dropLng
                                operationCityId:$rootScope.operationCityId
                            },
                            function(response) {
                                console.log('log : ' + JSON.stringify(response));

                                $scope.bookingFare = [];
                                $scope.invoiceChargeDetail = response;

                                var totalAmount = 0;
                                var tempInvoiceHeadId = 0;
                                var tempInvoiceHeadName = '';
                                var headAmount = 0;

                                for (var i = 0; i < response.length; i++) {
                                    if (response[i].invoiceHeadId !== tempInvoiceHeadId) {
                                        if (i !== 0) {
                                            $scope.bookingFare.push({
                                                invoiceHeadName: tempInvoiceHeadName,
                                                amount: headAmount
                                            });
                                        }
                                        headAmount = 0;
                                        headAmount = headAmount + response[i].amount;
                                        tempInvoiceHeadId = response[i].invoiceHeadId;
                                        tempInvoiceHeadName = response[i].invoiceHeadName;
                                    } else {
                                        headAmount = headAmount + response[i].amount;
                                    }
                                    totalAmount = totalAmount + response[i].amount;
                                }

                                $scope.bookingFare.push({
                                    invoiceHeadName: tempInvoiceHeadName,
                                    amount: headAmount
                                });

                                $scope.totalAmount = totalAmount;

                                $ionicLoading.hide();
                            },
                            function(error) {
                                $cordovaDialogs.alert('Please check internet connection and try again later.', 'Alert');
                                $state.go('newBooking');
                                $ionicLoading.hide();

                            });


                    } else {

                        FareMatrix.calculateFare({
                                carType: $rootScope.bookingDetails.carType.substr(0, 1),
                                isRoundTrip: isRoundTrip,
                                isOutstation: isOutstation,
                                actualReportingDate: actualReportingDate,
                                actualReportingTime: actualReportingTime,
                                actualReleivingDate: actualReleivingDate,
                                actualReleivingTime: actualReleivingTime,
                                pickupLat: 18.5240566,//$rootScope.bookingDetails.pickupLat,
                                pickupLng: 73.8646945,//$rootScope.bookingDetails.pickupLng,
                                dropLat:18.5240566,// $rootScope.bookingDetails.dropLat,
                                dropLng: 73.8646945,
                                operationCityId:$rootScope.operationCityId
                            },
                            function(response) {


                                $scope.bookingFare = [];
                                $scope.invoiceChargeDetail = response;

                                var totalAmount = 0;
                                var tempInvoiceHeadId = 0;
                                var tempInvoiceHeadName = '';
                                var headAmount = 0;

                                for (var i = 0; i < response.length; i++) {
                                    if (response[i].invoiceHeadId !== tempInvoiceHeadId) {
                                        if (i !== 0) {
                                            $scope.bookingFare.push({
                                                invoiceHeadName: tempInvoiceHeadName,
                                                amount: headAmount
                                            });
                                        }
                                        headAmount = 0;
                                        headAmount = headAmount + response[i].amount;
                                        tempInvoiceHeadId = response[i].invoiceHeadId;
                                        tempInvoiceHeadName = response[i].invoiceHeadName;
                                    } else {
                                        headAmount = headAmount + response[i].amount;
                                    }
                                    totalAmount = totalAmount + response[i].amount;
                                }

                                $scope.bookingFare.push({
                                    invoiceHeadName: tempInvoiceHeadName,
                                    amount: headAmount
                                });

                                $scope.totalAmount = totalAmount;

                                $ionicLoading.hide();
                            },
                            function(error) {
                                $cordovaDialogs.alert('Please check internet connection and try again later.', 'Alert');
                                $state.go('newBooking');
                                $ionicLoading.hide();

                            });
                    }

                        },function(r){
                    });
                    }

                    
                };

                $scope.bookingSave= function(){
                    $scope.isDisabled = true;
                    console.log('save');
                }

                $scope.saveBooking = function() {
                    $scope.loadingIndicator = $ionicLoading.show({
                        template: '<ion-spinner icon="spiral"></ion-spinner>'

                    });
                     

                    var rptDate = $rootScope.bookingDetails.rptDate;

                    if ($rootScope.bookingDetails.rptHour.value === 12 && $rootScope.bookingDetails.rptTime.value === 'AM') {
                        rptDate.setHours(0, parseInt($rootScope.bookingDetails.rptMinute.value));
                    } else if ($rootScope.bookingDetails.rptHour.value < 12 && $rootScope.bookingDetails.rptTime.value === 'PM') {
                        rptDate.setHours(($rootScope.bookingDetails.rptHour.value + 12), parseInt($rootScope.bookingDetails.rptMinute.value));
                    } else {
                        rptDate.setHours($rootScope.bookingDetails.rptHour.value, parseInt($rootScope.bookingDetails.rptMinute.value));
                    }

                    var d1 = new Date(rptDate);

                    var isOutstation = false;
                    var isRoundTrip = false;

                    if ($rootScope.bookingDetails.dutyType === 'Outstation') {
                        isOutstation = true;
                    }

                    if ($rootScope.bookingDetails.routeType === 'Round Trip') {
                        isRoundTrip = true;
                    }

                    var releivingDuration = 0;
                    var relDate = null;
                    var relTime = null;
                    var hours, minutes;
                    var cityName = null;
                    var cityLat = null;
                    var cityLng = null;



                    if (isOutstation) {
                        cityLat = 0;//$rootScope.bookingDetails.outstationCityLat;
                        cityLng = 0;//$rootScope.bookingDetails.outstationCityLng;
                        cityName = $rootScope.bookingDetails.outstationCity;
                    } else {

                    }



                    if (isOutstation) {
                        relDate = $rootScope.bookingDetails.relDate;
                        relTime = $rootScope.bookingDetails.relHour.value + ':' + $rootScope.bookingDetails.relMinute.value + ' ' + $rootScope.bookingDetails.relTime.value;
                    } else {
                        hours = d1.getHours();
                        minutes = d1.getMinutes();
                        d1.setHours((hours + parseInt($rootScope.bookingDetails.relHour.value)), (minutes + parseInt($rootScope.bookingDetails.relMinute.value)), 0, 0);
                        relDate = d1;
                        hours = d1.getHours();
                        minutes = d1.getMinutes();
                        relTime = hours + ':' + minutes;
                        releivingDuration = ($rootScope.bookingDetails.relHour.value * 60) + parseInt($rootScope.bookingDetails.relMinute.value);
                        relDate = $rootScope.bookingDetails.relDate;
                    }





                    CustomerDetails.findOne({
                            filter: {
                                where: {
                                    conuserId: $rootScope.user.id
                                }
                            }
                        },
                        function(response) {

                            $scope.customerId = response.id;

                            Bookings.createNewBooking({
                                        'carType': $rootScope.bookingDetails.carType.substr(0, 1),
                                        'isRoundTrip': isRoundTrip,
                                        'isOutstation': isOutstation,
                                        'reportingDate': $rootScope.bookingDetails.rptDate,
                                        'reportingTime': $rootScope.bookingDetails.rptHour.value + ':' + $rootScope.bookingDetails.rptMinute.value + ' ' + $rootScope.bookingDetails.rptTime.value,
                                        'releivingDate': relDate,
                                        'releivingTime': relTime,
                                        'releavingDuration': releivingDuration,
                                        'landmark': $rootScope.bookingDetails.landmark,
                                        'pickupAddress': $rootScope.bookingDetails.pickupAddress,
                                        'pickupLat': 0,//$rootScope.bookingDetails.pickupLat,
                                        'pickupLng': 0,//$rootScope.bookingDetails.pickupLng,
                                        'dropAddress': $rootScope.bookingDetails.dropAddress,
                                        'dropLat': 0,//$rootScope.bookingDetails.dropLat,
                                        'dropLng': 0,//$rootScope.bookingDetails.dropLng,
                                        'cityName': cityName,
                                        'cityLat': cityLat,
                                        'cityLng': cityLng,
                                        'totalAmount': $scope.totalAmount,
                                        'customerId': $scope.customerId,
                                        'userId': $rootScope.user.id,
                                        'paymentMethod': 'D',
                                        'operationCity' :$rootScope.operationCity
                                    },
                                    function(response) {
                                        if(response[0].create_booking === 'undefined'){
                                            $scope.isDisabled = false;
                                        $cordovaDialogs.alert('Unable to register your request. Please try again later.', 'Alert');
                                        $ionicLoading.hide();
                                    }else{
                                        $ionicLoading.hide();
                                        $rootScope.hide();
                                        $scope.thanksMsgModal.show();
                                        $scope.bookConfirmModal.hide();
                                        
                                        $state.go('newBooking');

                                        var dutyType;
                                        var journeyType;
                                        if (isOutstation === true) {
                                            dutyType = 'Outstation';
                                        } else {
                                            dutyType = 'Local';
                                        }

                                        if (isRoundTrip === true) {
                                            journeyType = 'Round Trip';
                                        } else {
                                            journeyType = 'One Way';
                                        }

                                         $scope.bId = response[0].create_booking;

                                         Bookings.findById({
                                            id: $scope.bId
                                        },function(bookings){

                                             $scope.cty = bookings.operationCity;
                                              Cities.findOne({
                                                filter:{
                                                    where:{
                                                       cityName:$scope.cty 
                                                    }
                                                }
                                            },function(citydetails){
                                               // console.log('cityName: '+JSON.stringify(city));
                                                $scope.contactNumber = citydetails.contactNumber;
                                                 $rootScope.contactNumber = citydetails.contactNumber;
                                                if (isOutstation === true) {
                                            var msg = 'Hi ' + $rootScope.user.firstName + ',%0a Your booking Id: ' + $scope.bId + ', Reporting ' + $filter('date')($rootScope.bookingDetails.rptDate, 'dd/MM/yyyy') + '@' +
                                                +$rootScope.bookingDetails.rptHour.value + ':' + $rootScope.bookingDetails.rptMinute.value + $rootScope.bookingDetails.rptTime.value +' Releiving @' + $filter('date')(relDate, 'dd/MM/yyyy') + '@' +
                                                relTime + ' for a ' + dutyType + ' ' + journeyType +
                                                ' has been received, driver details will be shared two hours before the trip. Driver\'s food allowance is included in the bill. For queries kindly contact '+$scope.contactNumber+' or info@indian-drivers.com. ';
                                        } else {
                                            var msg = 'Hi ' + $rootScope.user.firstName + ',%0a Your booking Id: ' + $scope.bId + ', Reporting ' + $filter('date')($rootScope.bookingDetails.rptDate, 'dd/MM/yyyy') + '@' +
                                                +$rootScope.bookingDetails.rptHour.value + ':' + $rootScope.bookingDetails.rptMinute.value + $rootScope.bookingDetails.rptTime.value + ' for ' + $rootScope.bookingDetails.relHour.value + $rootScope.bookingDetails.relMinute.value + ' ' + dutyType + ' ' + journeyType +
                                                ' has been received, driver details will be shared two hours before the trip. For queries kindly contact ' +$scope.contactNumber +' or info@indian-drivers.com.';
                                        }


                                        sendBookingRelatedSMS($rootScope.user.mobileNumber, msg);
                                        var msg1 = 'Dear ' + $rootScope.user.firstName + ',%0a We have taken utmost care while selecting driver, however we are not responsible for any type of losses including financial with respect to services. Need to make payment by cash immediately once the trip is over. If not agree with this terms, please cancel the booking. For queries '+$scope.contactNumber+' or info@indian-drivers.com. ';
                                        sendBookingRelatedSMS($rootScope.user.mobileNumber, msg1);
                                        $scope.resetBookingDetails();
                                        $rootScope.outStationCity = null;
                                        $ionicLoading.hide();

                                            },function(error){
                                               // console.log('error: '+JSON.stringify(error));
                                            });  
                                         },function(Bookinger){

                                         });

                                    }
                                        
                                        
                                    },
                                    function(error) {
                                        $scope.isDisabled = false;
                                        $cordovaDialogs.alert('Unable to register your request. Please try again later.', 'Alert');
                                        $ionicLoading.hide();
                                    });
                        },
                        function(error) {
                            $ionicLoading.hide();
                        });

                };

                function sendBookingRelatedSMS(mobileno, token) {
                    ConUsers.sendSMS({
                        mobileNumber: mobileno,
                        msg: token
                    }, function(success) {
                        console.log('message sent: ' + JSON.stringify(success));

                    }, function(error) {
                        console.log('message error: ' + JSON.stringify(error));
                    });
                }


                $scope.cancel = function() {
                    if (angular.isDefined($rootScope.map)) {
                        $rootScope.map.setClickable(true);
                    }
                    $state.go('newBooking');
                };

                $scope.closeThanksModal = function() {
                    $scope.thanksMsgModal.hide();
                    if (angular.isDefined($rootScope.map)) {
                        $rootScope.map.setClickable(true);
                        setMapHeight();
                        $scope.initMap();
                        $scope.locationMarker = ENV.locationMarker;
                    }
                    $state.go('newBooking');
                };

                $scope.disableTap = function() {

                    if (angular.isDefined($rootScope.map)) {
                        $rootScope.map.setClickable(false);
                    }

                    var container = document.getElementsByClassName('pac-container');
                    angular.element(container).attr('data-tap-disabled', true);

                    angular.element(container).on('click', function() {

                    });
                };

                $scope.setPickUpLocationThroughFavAddress = function(lat, logn, address) {
                    var pickupLocation = {
                        "lat": lat,
                        "lng": logn
                    }
                    $scope.addressModal.hide();

                    $rootScope.formattedAddress = address;
                    $scope.position = pickupLocation;

                    $scope.searchModal.hide();
                    $rootScope.map.moveCamera({
                            'target': $scope.position,
                            'tilt': 30,
                            'zoom': 15,
                            'bearing': 140
                        },
                        function() {

                        });
                    if (angular.isDefined($rootScope.map)) {
                        $rootScope.map.setClickable(true);
                    }
                }

                $scope.goToSearchLocation = function(searchLocation) {



                    $http.get('https://maps.googleapis.com/maps/api/geocode/json?&address=' + searchLocation +'&key=AIzaSyBlXlx9TZQ2MRMxeZHwQ5PX5hozA0vklcE')
                        .then(function successCallback(response) {



                            var i;
                            $scope.isPickupLocationPune = false;

                            for (i = 0; i <= response.data.results[0].address_components.length; i++) {
                                if (!angular.isUndefined(response.data.results[0].address_components[i])) {
                                    if (response.data.results[0].address_components[i].types[0] === 'administrative_area_level_2') {

                                        if (response.data.results[0].address_components[i].long_name === 'Pune' || response.data.results[0].address_components[i].long_name === 'Aurangabad') {
                                            $scope.isPickupLocationPune = true;
                                        }

                                    }
                                }
                            }
                            if ($scope.isPickupLocationPune === false && $rootScope.footerTitle != 'Set As Drop Location') {
                                $cordovaDialogs.alert('Pickup Location must be Pune or Aurangabad. ', 'New Booking');
                            } else {
                                $scope.closeSearchModal();
                                $rootScope.formattedAddress = searchLocation;
                                $scope.position = response.data.results[0].geometry.location;

                                $rootScope.map.moveCamera({
                                        'target': $scope.position,
                                        'tilt': 30,
                                        'zoom': 15,
                                        'bearing': 140
                                    },
                                    function() {

                                    });
                                if (angular.isDefined($rootScope.map)) {
                                    $rootScope.map.setClickable(true);
                                }

                            }
                        }, function errorCallback(response) {
                            $rootScope.search = 0;

                        });
                };

                $scope.closeReleivingDateModal = function() {
                    $scope.relDateModal.hide();

                };

                $scope.closeReleivingTimeModal = function() {
                    $scope.relTimeModal.hide();

                };


                $scope.searchLocation = function() {

                    $scope.getCustomerFavouriteAddresses();
                    $scope.searchModal.show();
                    if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                        $rootScope.map.setClickable(false);
                    }
                };

                $scope.getSearchResult = function(searchText) {
                    var url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' + searchText + '&components=country:in&types=geocode&language=en&key=AIzaSyAgUN6r05_PoTyEQFBilLtB_DJLcfofcaA';
                    $http.get(url)
                        .then(function successCallback(response) {
                            if (angular.isDefined(response.data.predictions)) {

                                $scope.searchResult = response.data.predictions;
                            }
                        }, function errorCallback(response) {

                        });
                };

                $scope.searchCity = function(searchText) {
                    var url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' + searchText + '&components=country:in&types=(cities)&language=en&key=AIzaSyAgUN6r05_PoTyEQFBilLtB_DJLcfofcaA';
                    $http.get(url)
                        .then(function successCallback(response) {

                            if (angular.isDefined(response.data.predictions)) {

                                $scope.searchResult = response.data.predictions;
                            }
                        }, function errorCallback(response) {

                        });
                };

                $scope.enableText = function() {
                    $rootScope.enableText = false;
                    $rootScope.enableText1 = true;
                    $scope.openLandmarkModel();
                };

                $scope.closeSearchModal = function() {

                    if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                        $rootScope.map.setClickable(true);
                    }
                    $scope.searchModal.hide();
                };
                $scope.closeSearchModal = function() {

                    if (!angular.isUndefined($rootScope.map) && $rootScope.map !== null) {
                        $rootScope.map.setClickable(true);
                    }
                    $scope.searchModal.hide();
                };



                $scope.scrollTop = function() {
                    $ionicScrollDelegate.scrollTop();
                };

                $scope.scrollBottom = function() {
                    $ionicScrollDelegate.scrollBottom();
                };





                $scope.getCustomerFavouriteAddresses = function() {
                    $scope.customerId = null;

                    CustomerDetails.find({
                            filter: {
                                where: {
                                    conuserId: $rootScope.user.id
                                }
                            }
                        },
                        function(response) {

                            $scope.customerId = response[0].id;

                            Bookings
                                .getFavAddress({
                                        customerId: $scope.customerId
                                    },
                                    function(response) {

                                        $scope.searchResult = response;

                                        if (angular.isDefined($rootScope.map)) {
                                            $rootScope.map.setClickable(false);
                                        }


                                    },
                                    function(error) {


                                    });


                        },
                        function(error) {
                            $cordovaDialogs.alert('Internet connection is not stable. Please try again.', 'New Booking');
                        });
                }

                $scope.setCurrentLocation = function() {
                    $rootScope.setCurrentLocationFlag = 1;

                    $scope.initMap();
                }

            }
        ])
        .directive('googleplace', function() {
            return {
                require: 'ngModel',
                link: function(scope, element, attrs, model) {
                    var options = {
                        types: [],
                        componentRestrictions: {}
                    };

                    scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

                    google.maps.event.addListener(scope.gPlace, 'place_changed', function() {
                        scope.$apply(function() {
                            model.$setViewValue(element.val());
                        });
                    });
                }
            };
        });
}());