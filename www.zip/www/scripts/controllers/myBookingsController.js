/**
 * @ngdoc function
 * @name starter.controller:myBookingsCtrl
 * @description
 * # myBookingsCtrl
 * My Booking controller of the app
 */
'use strict';
angular.module('ionicControllers')
    .controller('myBookingsCtrl', ['$rootScope', '$scope', '$state', '$filter', '$ionicViewService', '$ionicHistory', '$timeout', '$ionicLoading', '$cordovaDialogs', 'ENV', 'API', '$ionicModal', '$http', 'Bookings', 'CancellationReasons', 'CustomerDetails', 'DriverDetails', 'BookingPaymentTransaction', 'Invoices',
        function($rootScope, $scope, $state, $filter, $ionicViewService, $ionicHistory, $timeout, $ionicLoading, $cordovaDialogs, ENV, API, $ionicModal, $http, Bookings, CancellationReasons, CustomerDetails, DriverDetails, BookingPaymentTransaction, Invoices) {

$scope.subMenu =false;
            $scope.myBookings = null;
            $scope.selectedReasion = null;
            $scope.invalidReason = null;
            $scope.invalidComment = null;
            $scope.pay = false;
            $rootScope.bookingId = [];
            $scope.$on('$ionicView.enter', function(event, data) {
                var stateName = data.stateName;
                if (stateName === 'myBookings') {
                    $rootScope.menuComponentId = 'bookings-left';
                } else if (stateName === 'invoice') {
                    $rootScope.menuComponentId = 'invoice-left';
                }

            });
            $scope.PayOnline = function() {
                $rootScope.totalAmount = 0;
                var count = null;
                var amount = null;
                var customer_id = $rootScope.user.customerId;
                var email = $rootScope.user.email;
                var phone = $rootScope.user.mobileNumber;
                var txn_id = null;
                for (var i = 0; i < $scope.bookingId.length; i++) {
                    var bcount = $scope.bookingId.length;
                    var bookingId = $scope.bookingId[i];
                    Bookings.findOne({
                            filter: {
                                where: {
                                    id: bookingId
                                },
                                include: {
                                    relation: 'invoices'
                                }


                            }

                        },
                        function(response) {
                            if (txn_id === null) {
                                txn_id = i;
                            } else {
                                txn_id = txn_id + '_' + bcount;
                            }

                            //console.log('transactionid : ' + JSON.stringify(count));
                            console.log('Booking Object : ' + JSON.stringify(response));
                            amount = response.invoices[0].netAmount;
                            if (response.isOutstation === true) {
                                amount = amount - 50;
                            } else {
                                amount = amount - 25;
                            }
                            if ($rootScope.totalAmount === 0) {
                                $rootScope.totalAmount = amount;

                            } else {
                                $rootScope.totalAmount = $rootScope.totalAmount + amount;
                            }

                            bcount--;
                            if (bcount === 0) {
                                console.log('amount : ' + JSON.stringify($rootScope.totalAmount));
                                console.log('transactionid : ' + JSON.stringify(txn_id));
                                for (var j = 0; j < $scope.bookingId.length; j++) {
                                    var bookingId = $scope.bookingId[j];
                                    var ccount = $scope.bookingId.length;
                                    BookingPaymentTransaction.create({
                                            bookingId: bookingId,
                                            transactionId: txn_id,
                                            transactionStatus: 'Initiated',
                                            createdBy: customer_id
                                        },
                                        function(response) {
                                            console.log('Success response is' + JSON.stringify(response));
                                            ccount--;
                                            if (ccount === 0) {

                                                $rootScope.totalAmount = $rootScope.totalAmount.toFixed(2);
                                                console.log('txn_id:' + txn_id + 'customer id:' + customer_id + 'email' + email + 'phone' + phone + 'amount' + $rootScope.totalAmount);
                                                window.plugins.paytm.startPayment(txn_id, customer_id, email, phone, $rootScope.totalAmount,
                                                    function(transactionResponse) {
                                                        console.log('payment successfull response : ' + JSON.stringify(transactionResponse));
                                                        $rootScope.transactionDetail = transactionResponse;
                                                        for (var k = 0; k < $scope.bookingId.length; k++) {
                                                            var bookingId = $scope.bookingId[k];
                                                            var dcount = $scope.bookingId.length;
                                                            Invoices.postOnlinePayment({
                                                                    bookingId: bookingId
                                                                },
                                                                function(response) {
                                                                    console.log('Booking Details' + JSON.stringify(response));
                                                                    dcount--;
                                                                    if (dcount === 0) {
                                                                        BookingPaymentTransaction.find({
                                                                                filter: {
                                                                                    where: {
                                                                                        transactionId: txn_id
                                                                                    }
                                                                                }
                                                                            },
                                                                            function(response) {
                                                                                console.log('Booking Payment transaction value' + JSON.stringify(response[0]));
                                                                                response[0].transactionResponse = transactionResponse;
                                                                                response[0].transactionStatus = 'Success';
                                                                                response[0].$save();
                                                                                $rootScope.successTransactionId = response[0].transactionId;
                                                                                $rootScope.transactionAmount = $rootScope.totalAmount;
                                                                                $rootScope.transactionBookingId = $scope.bookingId;
                                                                                $scope.showPaymentSuccessModal();
                                                                                //$state.go('myBookings');

                                                                            },
                                                                            function(error) {
                                                                                console.log('Fetching booking transaction object fail : ' + JSON.stringify(error));
                                                                            });
                                                                    }

                                                                },
                                                                function(error) {
                                                                    console.log('Error in postOnlinePayment');
                                                                });
                                                        }

                                                    },
                                                    function(error) {

                                                        console.log('payment error : ' + JSON.stringify(error));
                                                        BookingPaymentTransaction.find({
                                                                filter: {
                                                                    where: {
                                                                        transactionId: txn_id
                                                                    }
                                                                }
                                                            },
                                                            function(response) {
                                                                console.log('Booking Payment transaction value' + JSON.stringify(response));
                                                                response[0].transactionResponse = $rootScope.transactionDetail;
                                                                response[0].transactionStatus = 'Fail';
                                                                response[0].$save();

                                                            },
                                                            function(error) {
                                                                console.log('Fetching booking transaction object fail : ' + JSON.stringify(error));
                                                            });

                                                    });
                                            }

                                        },
                                        function(error) {
                                            console.log('Error Create Booking Transaction' + JSON.stringify(error));
                                        });
                                }

                            }
                        },
                        function(err) {

                        });

                }



            };
            
            $scope.check = function(bookingId) {

                $scope.pay = true;

                console.log('id : ' + JSON.stringify(bookingId));
                if ($rootScope.bookingId.indexOf(bookingId) == -1) {

                    $rootScope.bookingId.push(bookingId);

                } else {

                    for (var i = $rootScope.bookingId.length - 1; i >= 0; i--) {

                        if ($rootScope.bookingId[i] == bookingId) {
                            console.log('duplicate id is:' + JSON.stringify(bookingId));
                            $rootScope.bookingId.splice(i, 1);
                            console.log('deleted id is:' + JSON.stringify(bookingId));

                        }

                    }
                }
                console.log('bookingId: ' + JSON.stringify($scope.bookingId));

            }
            $scope.closeBookingCancelMsg = function() {
                $scope.bookingCancelMsgModal.hide();
                $state.go('myBookings');
                $rootScope.menuComponentId = 'bookings-left';
            };
            $scope.timediff = function(start, end) {
                return moment.utc(moment(end).diff(moment(start))).format("mm");
            }

            $ionicModal.fromTemplateUrl('templates/booking-cancelation-message-modal.html', function($ionicBookingCancelMsgModal) {
                $scope.bookingCancelMsgModal = $ionicBookingCancelMsgModal;
            }, {

                scope: $scope,

                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(bookingCancelMsgModal) {
                $scope.bookingCancelMsgModal = bookingCancelMsgModal;

            });


            $ionicModal.fromTemplateUrl('templates/payment-success-message-modal.html', function($ionicPaymentSuccessMsgModal) {
                $scope.paymentSuccessModal = $ionicPaymentSuccessMsgModal;
            }, {

                scope: $scope,

                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(paymentSuccessModal) {
                $scope.paymentSuccessModal = paymentSuccessModal;

            });


            $scope.convertMinutesToHours = function(date, time, date2, time2) {
                var date = $filter('date')(date, 'yyyy-MM-dd');
                var datetime = new Date(date + ' ' + time);

                /*console.log(date);
                console.log(time);
                console.log(datetime);*/
                var date2 = $filter('date')(date2, 'yyyy-MM-dd');
                var datetime2 = new Date(date2 + ' ' + time2);

                var diff = Math.abs(datetime2.getTime() - datetime.getTime());

                /*console.log(datetime2);
                console.log(diff);*/
                var seconds = Math.floor(diff / 1000);
                var h = 3600;
                var m = 60;
                var hours = Math.floor(seconds / h);
                var minutes = Math.floor((seconds % h) / m);
                var scnds = Math.floor((seconds % m));
                var timeString = '';
                if (scnds < 10) scnds = "0" + scnds;
                if (hours < 10) hours = "0" + hours;
                if (minutes < 10) minutes = "0" + minutes;
                timeString = hours + " Hours " + minutes + " Minutes";
                return timeString;

            };

            $scope.fetchMyBookings = function() {



                $scope.customerId = null;

                CustomerDetails.find({
                        filter: {
                            where: {
                                conuserId: $rootScope.user.id
                            }
                        }
                    },
                    function(response) {


                        $scope.customerId = response[0].id;
                        Bookings.find({
                                filter: {
                                    where: {
                                        customerId: $scope.customerId
                                    },
                                    include: [{
                                        relation: 'invoices',
                                        scope: {
                                            include: {
                                                relation: 'invoiceDetails'
                                            }
                                        }
                                    }, {
                                        relation: 'localBookings'
                                    }, {
                                        relation: 'outstationBookings'
                                    }, {
                                        relation: 'driverDetails',
                                        scope: {
                                            include: {
                                                relation: 'conUsers'
                                            }
                                        }
                                    }],
                                    order: 'id DESC',
                                    limit: 10
                                }   
                            },
                            function(response) {
                                /*console.log('my booking '+JSON.stringify(response));*/
                                $scope.myBookings = response;
                            },
                            function(error) {

                            });

                    },
                    function(error) {
                        // $cordovaDialogs.alert('Error in Fetching Customer Id', 'New Booking');
                    });


            };

            $scope.viewBookingDetail = function(index) {



                Bookings.find({
                        filter: {
                            where: {
                                id: $scope.myBookings[index].id
                            },
                            include: [{
                                relation: 'invoices',
                                scope: {
                                    include: {
                                        relation: 'invoiceDetails',
                                        scope: {
                                            include: {
                                                relation: 'invoiceSubHeads'
                                            }
                                        }
                                    },
                                    order: 'id DESC',
                                    limit: 1
                                }
                            }, {
                                relation: 'localBookings'
                            }, {
                                relation: 'outstationBookings'
                            }]
                        }
                    },
                    function(response) {
                        console.log(' booking details: ' + JSON.stringify(response));
                        $rootScope.bookingDetail = response;
                        if (angular.isDefined($rootScope.bookingDetail[0].outstationBookings[0])) {
                            if ($rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime !== null) {
                                var returnTime = $rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime.toFixed(2);
                                var array = returnTime.split('.');
                                //var array =$rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime.split('.');
                                var returnTravelHour = parseInt(array[0]);
                                var returnTravelMinute = parseInt(array[1]);
                                if (returnTravelMinute < 10) {
                                    returnTravelMinute = '0' + returnTravelMinute;
                                }
                                returnTravelMinute = returnTravelMinute * 0.6;
                                returnTravelMinute = Math.round(returnTravelMinute);
                                $rootScope.time1 = returnTravelHour + ' Hours ' + returnTravelMinute + ' Minutes';
                            }
                        }


                        $rootScope.baseFare = null;
                        $rootScope.returnFare = null;
                        if (response[0].driverId != null) {

                            DriverDetails.find({
                                    filter: {
                                        where: {
                                            id: response[0].driverId
                                        },
                                        include: {
                                            relation: 'conUsers'
                                        }


                                    }
                                },
                                function(driverDetailresponse) {
                                    $rootScope.driverDetailOfViewBooking = driverDetailresponse;

                                    $rootScope.viewInvoiceDetail = response[0].invoices[0].invoiceDetails;

                                    var currentTime = response[0].invoices[0].releavingTime;
                                    $rootScope.dropTimeHour = currentTime.split(':')[0];


                                    $rootScope.menuComponentId = 'invoice-left';
                                    $rootScope.viewDetailFooter = 'Cancel Booking';
                                    $state.go('invoice');
                                },
                                function(error) {
                                    // $cordovaDialogs.alert('Error in fetching Driver Detail', 'My Booking');
                                });


                        } else {
                            $rootScope.viewInvoiceDetail = response[0].invoices[0].invoiceDetails;
                            var currentTime = response[0].invoices[0].releavingTime;
                            $rootScope.dropTimeHour = currentTime.split(':')[0];

                            $rootScope.menuComponentId = 'invoice-left';
                            $rootScope.viewDetailFooter = 'Cancel Booking';
                            $state.go('invoice');
                        }

                    },
                    function(error) {

                    });


            };


            $scope.cancelBooking = function() {

                $state.go('cancelBooking');
            };

            $scope.fetchCancelReasion = function() {

                CancellationReasons.find({},
                    function(response) {

                        $scope.cancelationReasion = response;
                    },
                    function(error) {

                    });
            };

            $scope.submitCancellationReason = function(selectedReasion, comment)
            {
                $scope.invalidReason = null;
                $scope.invalidComment = null;


                if ((angular.isUndefined(selectedReasion) || selectedReasion == '') && (comment === '' || angular.isUndefined(comment))) {
                    $scope.invalidReason = 'Enter Cancellation Reason.';
                    $scope.invalidComment = 'Enter Cancellation Comment';
                } else if (angular.isUndefined(selectedReasion) || selectedReasion === '') {
                    $scope.invalidReason = 'Enter Cancellation Reason.';
                } else if (angular.isUndefined(comment) || comment === '') {
                    $scope.invalidComment = 'Enter Cancellation Comment';
                } else {
                    var name = $rootScope.ConUsers.user.firstName + ' ' + $rootScope.ConUsers.user.lastName
                    $rootScope.cancelDate = ' Booking cancelled by ' + name + ' on '


                    Bookings.cancelBooking({
                            bookingId: $rootScope.bookingDetail[0].id,
                            cancellationId: selectedReasion.id,
                            cancellationReason: comment + ' ' + $rootScope.cancelDate
                        },
                        function(response) {
                            if (response[0].cancel_booking === 'Cancelled') {
                                $scope.bookingCancelMsgModal.show();
                            } else if (response[0].cancel_booking === 'On Duty') {
                                $cordovaDialogs.alert('This duty has already started! You can not cancel this duty.', 'Alert');
                                $state.go('myBookings');
                            } else if (response[0].cancel_booking === 'Done') {
                                $cordovaDialogs.alert('This duty has already done! You can not cancel this duty.', 'Alert');
                                $state.go('myBookings');
                            } else if (response[0].cancel_booking === 'Paid') {
                                $cordovaDialogs.alert('This duty status is paid! You can not cancel this duty.', 'Alert');
                                $state.go('myBookings');
                            } else {

                            }


                        },
                        function(er) {

                        });
                }
            };



            $scope.closeInvoiceSentMsg = function() {

                $state.go('myBookings');
                $rootScope.menuComponentId = 'bookings-left';
            };

            $scope.closePaymentSuccessModal = function() {
                $scope.paymentSuccessModal.hide();

                $scope.fetchMyBookings();
            };

            $scope.showPaymentSuccessModal = function() {

                $scope.paymentSuccessModal.show();

            };

            $scope.fetchPaymentSuccessData = function() {



                var paymentSuccessData = [];

                BookingPaymentTransaction.find({
                        filter: {
                            where: {
                                transactionId: $rootScope.successTransactionId
                            }
                        }
                    },
                    function(response) {
                            if(response.length>0){
                                 paymentSuccessData.push({
                            id: response[0].transactionId,
                            transactionDate: response[0].createdDate

                        });

                        $rootScope.paymentSuccessDetails = paymentSuccessData;
                            }

                       


                    },
                    function(error) {

                    });
 
            };

            $scope.converToTwelveHour = function(time) {
                if (!angular.isUndefined(time)) {
                    var hours = time.split(':')[0];
                    var minutes = time.split(':')[1];
                    var ampm = hours >= 12 ? 'pm' : 'am';
                    hours = hours % 12;
                    hours = hours ? hours : 12;
                    if (minutes === '00') {
                        minutes = '00';
                    } else {
                        minutes = minutes < 10 ? minutes : minutes;
                    }
                    var strTime = hours + ':' + minutes + ' ' + ampm;
                }
                return strTime;
            };

            //Paytm 

            $scope.startPayment = function(index, payAmount, flag) {
                var count = null;
                var countWithA = null;
                var bookingId = null;
                var amount = null;
                var txn_id = null;


                var customer_id = $rootScope.user.customerId;
                var email = $rootScope.user.email;
                var phone = $rootScope.user.mobileNumber;


                if (flag === 'indexId') {
                    bookingId = $scope.myBookings[index].id;
                    amount = $scope.myBookings[index].invoices[0].netAmount.toFixed(2);
                } else if (flag === 'bookingId') {
                    bookingId = index;
                    amount = payAmount.toFixed(2);
                } else {

                }




                Bookings.findById({
                        id: bookingId
                    },
                    function(response) {
                        console.log('Booking Object : ' + JSON.stringify(response));
                        if (response.isOutstation === true) {
                            amount = amount - 50;
                        } else {
                            amount = amount - 25;
                        }

                        BookingPaymentTransaction.find({
                                filter: {
                                    where: {
                                        bookingId: bookingId
                                    }
                                }
                            },
                            function(response) {
                                console.log('Booking Transaction Object' + JSON.stringify(response[0]));
                                count = response.length;
                                console.log('Transaction Count: ' + count);
                                txn_id = count + 'A' + bookingId;
                                console.log('Transaction Id Is: ' + txn_id);

                                console.log('Transaction Id Is: ' + customer_id);


                                BookingPaymentTransaction.create({
                                        bookingId: bookingId,
                                        transactionId: txn_id,
                                        transactionStatus: 'Initiated',
                                        createdBy: customer_id
                                    },
                                    function(response) {
                                        console.log('Success response is' + JSON.stringify(response));
                                        console.log('txn_id:' + txn_id + 'customer id:' + customer_id + 'email' + email + 'phone' + phone + 'amount' + amount);
                                        window.plugins.paytm.startPayment(txn_id, customer_id, email, phone, amount,
                                            function(transactionResponse) {
                                                console.log('payment successfull response : ' + JSON.stringify(transactionResponse));
                                                $rootScope.transactionDetail = transactionResponse;

                                                Invoices.postOnlinePayment({
                                                        bookingId: bookingId
                                                    },
                                                    function(response) {
                                                        console.log('Booking Details' + JSON.stringify(response));

                                                        BookingPaymentTransaction.find({
                                                                filter: {
                                                                    where: {
                                                                        transactionId: txn_id
                                                                    }
                                                                }
                                                            },
                                                            function(response) {
                                                                console.log('Booking Payment transaction value' + JSON.stringify(response[0]));
                                                                response[0].transactionResponse = transactionResponse;
                                                                response[0].transactionStatus = 'Success';
                                                                response[0].$save();
                                                                $rootScope.successTransactionId = response[0].transactionId;
                                                                $rootScope.transactionAmount = amount;
                                                                $rootScope.transactionBookingId = bookingId;
                                                                $scope.showPaymentSuccessModal();
                                                                //$state.go('myBookings');

                                                            },
                                                            function(error) {
                                                                console.log('Fetching booking transaction object fail : ' + JSON.stringify(error));
                                                            });
                                                    },
                                                    function(error) {
                                                        console.log('Error in postOnlinePayment');
                                                    });

                                            },
                                            function(error) {

                                                console.log('payment error : ' + JSON.stringify(error));
                                                BookingPaymentTransaction.find({
                                                        filter: {
                                                            where: {
                                                                transactionId: txn_id
                                                            }
                                                        }
                                                    },
                                                    function(response) {
                                                        console.log('Booking Payment transaction value' + JSON.stringify(response));
                                                        response[0].transactionResponse = $rootScope.transactionDetail;
                                                        response[0].transactionStatus = 'Fail';
                                                        response[0].$save();

                                                    },
                                                    function(error) {
                                                        console.log('Fetching booking transaction object fail : ' + JSON.stringify(error));
                                                    });

                                            });

                                    },
                                    function(error) {
                                        console.log('Error Create Booking Transaction' + JSON.stringify(error));
                                    });


                            },
                            function(error) {
                                console.log('error fetching booking transaction : ' + JSON.stringify(error));
                            });


                    },
                    function(error) {
                        console.log('Error in fetching Booking Object : ' + JSON.stringify(error));
                    });


            };

            $scope.closePayment = function() {
                $scope.loadingIndicator = $ionicLoading.show({
                    template: '<ion-spinner icon="spiral"></ion-spinner>'

                });
                $ionicViewService.nextViewOptions({
                    disableBack: true
                });
                $ionicViewService.clearHistory();
                $ionicHistory.clearHistory();
                $state.go('newBooking');
                $timeout(function() {

                    $ionicLoading.hide();
                }, 1500);

            };


        }
    ]);
