/**
 * @ngdoc function
 * @name starter.controller:profileCtrl
 * @description
 * # profileCtrl
 * Profile controller of the app
 */
'use strict';
angular.module('ionicControllers')
    .controller('profileCtrl', ['$rootScope', '$scope', '$state', '$ionicViewService', '$ionicHistory', '$localStorage', '$ionicModal', '$filter', '$http', 'ENV', 'API', 'ConUsers', '$cordovaDialogs', 'CustomerDetails', 'Bookings', 'DriverDetails','Cities',
        function($rootScope, $scope, $state, $ionicViewService, $ionicHistory, $localStorage, $ionicModal, $filter, $http, ENV, API, ConUsers, $cordovaDialogs, CustomerDetails, Bookings, DriverDetails, Cities) {

            console.log('In profile controller');

$scope.subMenu =false;
            $scope.invalidFirstName = null;
            $scope.invalidLastName = null;
            $scope.inValidEmail = null;
            $scope.inValidMobileNo = null;
            $scope.inValidAddress = null;
            $scope.inValidAddress2 = null;
            $scope.isDuplicateMobileNo = true;
            $ionicModal.fromTemplateUrl('templates/search-address-modal.html', function($ionicSearchModal) {
                $scope.searchModal = $ionicSearchModal;
            }, {

                scope: $scope,
                focusFirstInput: true,
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(searchModal) {
                $scope.searchModal = searchModal;

            });



 $scope.operationCity = function() {
                  Cities.find({
                           
                   },function(citysuccess){
                       
                      $rootScope.cityAt = [];
        for(var i = 0; i<citysuccess.length; i++){
            
            if(citysuccess[i].cityName !== 'All'){
                $rootScope.cityAt.push(citysuccess[i].cityName);
            }
        }


                   },function(cityerr){ 
                 
                   });
              }
            $scope.goToSearchLocation = function(searchLocation) {

                $http.get('https://maps.googleapis.com/maps/api/geocode/json?&address=' + searchLocation +'&key=AIzaSyBLP7tw2TUXwhLr_usyrmPzK2nGwqMYdNU')
                    .then(function successCallback(response) {

                        $scope.addressLat = response.data.results[0].geometry.location.lat;
                        $scope.addressLon = response.data.results[0].geometry.location.lng;

                        $scope.closeSearchModal();
                        $scope.addressLine2 = searchLocation;
                        $scope.user.addressLine2 = searchLocation;
                        $scope.position = response.data.results[0].geometry.location;
                    }, function errorCallback(response) {
                        $rootScope.search = 0;

                    });
            };





            $scope.getSearchResult = function(searchText) {
                var url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' + searchText + '&components=country:in&types=geocode&language=en&key=' + ENV.googlePlacesAPIKey;
                $http.get(url)
                    .then(function successCallback(response) {
                        if (angular.isDefined(response.data.predictions)) {

                        }
                        $scope.searchResult = response.data.predictions;
                    }, function errorCallback(response) {

                    });
            };







            $scope.closeSearchModal = function() {

                $scope.searchModal.hide();
            };

            $scope.setAddress = function() {
                $scope.searchModal.show();
            };


            $scope.fetchUserDetails = function() {
                $rootScope.show();


                ConUsers.findById({

                        id: $rootScope.user.id
                    },
                    function(response) {


                        $rootScope.user = response;
                        $scope.user = response;
                        fetchCustomerObject();

                        $rootScope.menuComponentId = 'profile-left';
                        $rootScope.hide();
                    },
                    function(error) {

                    });
            }; /**/

            $scope.updateProfile = function(operation) {
                // $rootScope.show();
                if (operation === 'onlyUpdate') {
                    $scope.isDuplicateMobileNo = false;
                }

                var isValid = profileValidation($scope.user);
                if (isValid && !$scope.isDuplicateMobileNo) {



                    $scope.user.updatedBy = $rootScope.user.id;
                    $scope.user.updatedDate = new Date();

                    

                                var pickAddress1 = $scope.user.addressLine2;
                                pickAddress1 = pickAddress1.replace(/, Maharashtra/g, '');
                                pickAddress1 = pickAddress1.replace(/, India/g, '');
                                ConUsers.upsert({
                                        id: $scope.user.id,
                                        firstName: $scope.user.firstName,
                                        lastName: $scope.user.lastName,
                                        // mobileNumber: $scope.user.mobileNumber,
                                        email: $scope.user.email,
                                        address: $scope.user.address,
                                        addressLine2: pickAddress1,
                                        updatedBy: $scope.user.updatedBy,
                                        updatedDate: $scope.user.updatedDate,
                                        //addressLat: $scope.addressLat,
                                       // addressLong: $scope.addressLon,
                                        operationCity: $scope.user.operationCity
                                    }, function(res) {
                                        $rootScope.operationCity = $scope.user.operationCity; 
                                        if (operation === 'sendOTP') {
                                            fetchCustomerObject();
                                            $state.go('verifOTPNo');
                                        } else {
                                            fetchCustomerObject();
                                            $rootScope.menuComponentId = 'profile-left';
                                            $rootScope.hide();
                                        }
                                    },
                                    function(error) {
                                        if (error.status === 422) {

                                            if (angular.isDefined(error.data.error.details.messages.username)) {
                                                $scope.inValidMobileNo = 'Mobile Number Already Exist';
                                                $rootScope.hide();
                                            }
                                            if (angular.isDefined(error.data.error.details.messages.email)) {
                                                $scope.inValidEmail = 'Email Already Exist';
                                                $rootScope.hide();
                                            }
                                        }

                                    });

                            


                    //var localaddress = $scope.user.address + ',' + $scope.user.address1;


                }
            };
            $scope.updateProfileInitial = function() {

                $rootScope.show();

                $scope.isDuplicateMobileNo = false;


                var isValid = profileValidation($scope.user);
                if (isValid && !$scope.isDuplicateMobileNo) {
                    console.log('User details : ' + JSON.stringify($scope.user));


                    $scope.user.updatedBy = $rootScope.user.id;
                    $scope.user.updatedDate = new Date();



                      



                    var pickAddress1 = $scope.user.addressLine2;
                    pickAddress1 = pickAddress1.replace(/, Maharashtra/g, '');
                    pickAddress1 = pickAddress1.replace(/, India/g, '');

                    ConUsers.upsert({
                            id: $scope.user.id,
                            firstName: $scope.user.firstName,
                            lastName: $scope.user.lastName, 
                            address: $scope.user.address,
                            email: $scope.user.email,
                            addressLine2: pickAddress1,
                            updatedBy: $scope.user.updatedBy,
                            updatedDate: $scope.user.updatedDate,
                            addressLat: 0,
                            addressLong: 0
                        }, function(res) {
                             $rootScope.landmark = $scope.user.address;
                            $rootScope.pickupAddress = pickAddress1;
                            fetchCustomerObject();

                            $rootScope.menuComponentId = 'profile-left';
                            if (angular.isDefined($localStorage.user.customerId)) {
                                paymentOperation();
                                $rootScope.hide();
                            }
                        },
                        function(error) {
                            if (error.status === 422) {

                                if (angular.isDefined(error.data.error.details.messages.username)) {
                                    $scope.inValidMobileNo = 'Mobile Number Already Exist';
                                    $rootScope.hide();
                                }
                                if (angular.isDefined(error.data.error.details.messages.email)) {
                                    $scope.inValidEmail = 'Email Already Exist';
                                    $rootScope.hide();
                                }
                            }

                        });
                    

                             

                    //var localaddress = $scope.user.address + ',' + $scope.user.address1;


                }
            };
            function paymentOperation() {


                Bookings.find({
                        filter: {
                            where: {

                                and: [{ customerId: $localStorage.user.customerId },
                                    {
                                        feedbackStatus: 'Initiated'
                                    }
                                ]


                            }
                        }
                    },
                    function(response) {


                        if (response.length !== 0) {

                            makePendingPayment(response[0].id);
                        } else {
                            $ionicViewService.nextViewOptions({
                                disableBack: true
                            });
                            $ionicViewService.clearHistory();
                            $ionicHistory.clearHistory();
                            $state.go('newBooking');
                            $rootScope.hide();
                        }

                    },
                    function(error) {

                    });
            }


            function makePendingPayment(bookingId) {

                Bookings.find({
                        filter: {
                            where: {
                                id: bookingId
                            },
                            include: [{
                                relation: 'invoices',
                                scope: {
                                    include: {
                                        relation: 'invoiceDetails',
                                        scope: {
                                            include: {
                                                relation: 'invoiceSubHeads'
                                            }
                                        }
                                    },
                                    order: 'id DESC',
                                    limit: 1
                                }
                            }, {
                                relation: 'localBookings'
                            }, {
                                relation: 'outstationBookings'
                            }]
                        }
                    },
                    function(response) {

                        $rootScope.bookingDetail = response;
                        if (angular.isDefined($rootScope.bookingDetail[0].outstationBookings[0])) {
                            if ($rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime !== null) {


                                var returnTime = $rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime.toFixed(2);
                                var array = returnTime.split('.');
                                //var array =$rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime.split('.');
                                var returnTravelHour = parseInt(array[0]);
                                var returnTravelMinute = parseInt(array[1]);
                                if (returnTravelMinute < 10) {
                                    returnTravelMinute = '0' + returnTravelMinute;
                                }
                                returnTravelMinute = returnTravelMinute * 0.6;
                                returnTravelMinute = Math.round(returnTravelMinute);
                                $rootScope.time2 = returnTravelHour + ' Hours ' + returnTravelMinute + ' Minutes';
                            }
                        }
                        $rootScope.baseFare = null;
                        $rootScope.returnFare = null;
                        if (response[0].driverId != null) {
                            DriverDetails.find({
                                    filter: {
                                        where: {
                                            id: response[0].driverId
                                        },
                                        include: {
                                            relation: 'conUsers'
                                        }


                                    }
                                },
                                function(response) {
                                    $rootScope.driverDetailOfViewBooking = response;

                                },
                                function(error) {
                                    // $cordovaDialogs.alert('Error in fetching Driver Detail', 'My Booking');
                                });


                        }
                        $rootScope.viewInvoiceDetail = response[0].invoices[0].invoiceDetails;
                    },
                    function(error) {

                    });
                $rootScope.menuComponentId = 'invoice-left';
                $rootScope.viewDetailFooter = 'Cancel Booking';

                if (angular.isDefined($rootScope.map)) {

                    if ($rootScope.map !== null) {
                        $rootScope.map.setClickable(false);
                    }

                }
                $ionicViewService.nextViewOptions({
                    disableBack: true
                });
                $ionicViewService.clearHistory();
                $ionicHistory.clearHistory();
                $state.go('makePendingPayment');
                $rootScope.hide();
            }


            function fetchCustomerObject() {


                ConUsers.findById({
                        id: $rootScope.user.id
                    },
                    function(response) {

                        $rootScope.user = response;
                        $scope.user = response;

                        CustomerDetails.findOne({
                                filter: {
                                    where: {
                                        conuserId: $rootScope.user.id
                                    }
                                }

                            },
                            function(customerResponse) {

                                $localStorage.user.customerId = customerResponse.id;
                                $rootScope.user.customerId = customerResponse.id;

                            },
                            function(error) {
                                $cordovaDialogs.alert(JSON.stringify(error));
                            });





                    },
                    function(error) {

                    });
            }



            $scope.saveProfile = function() {
                var isValid = profileValidation($scope.user);
                if (isValid && !$scope.isDuplicateMobileNo) {

                    $scope.user.updatedBy = $rootScope.user.id;
                    $scope.user.updatedDate = new Date();




                }
            };

            function profileValidation(user) {



                var isValid = true;
                $scope.invalidFisrtName = null;
                $scope.invalidLastName = null;
                $scope.inValidEmail = null;
                $scope.inValidMobileNo = null;
                $scope.inValidAddress = null;
                $scope.inValidAddress2 = null;

                if (angular.isUndefined(user)) {

                    $scope.invalidFirstName = 'First name is compulsory';
                    $scope.invalidLastName = 'Last name is compulsory';

                    $scope.inValidEmail = 'Email is compulsory';
                    $scope.inValidMobileNo = 'Mobile number is compulsory';
                    $scope.inValidAddress = 'Address is compulsory';
                    $scope.inValidAddress2 = 'AddressLine2 is compulsary';
                    isValid = false;
                    $rootScope.hide();
                } else {


                    if (angular.isUndefined(user.firstName) || user.firstName === '') {

                        $scope.invalidFirstName = 'First name is Compulsory';
                        isValid = false;
                        $rootScope.hide();
                    }
                    if (angular.isUndefined(user.lastName) || user.lastName === '') {
                        $scope.invalidLastName = 'Last name is Compulsory';
                        isValid = false;
                        $rootScope.hide();

                    }


                    if (angular.isUndefined(user.email)) {

                        $scope.inValidEmail = 'Email is Compulsory';
                        isValid = false;
                        $rootScope.hide();
                    } else {
                        var mailTest = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                        if (!mailTest.test(user.email)) {

                            $scope.inValidEmail = 'Please enter valid Email';
                            isValid = false;
                            $rootScope.hide();
                        }
                    }



                    if (angular.isUndefined(user.mobileNumber) || user.mobileNumber == null) {

                        $scope.inValidMobileNo = 'Mobile number is Compulsory';
                        isValid = false;
                        $rootScope.hide();
                    } else {
                        var mobileNo = user.mobileNumber;
                        if (mobileNo.toString().length != 10) {
                            $scope.inValidMobileNo = 'Mobile number should be 10 digit';
                            isValid = false;
                            $rootScope.hide();
                        }
                    }

                    if (angular.isUndefined(user.address)) {

                        $scope.inValidAddress = 'Address is compulsory';
                        isValid = false;
                        $rootScope.hide();
                    } else if (user.address == '' || user.address === null) {

                        $scope.inValidAddress = 'Address can not be blank';
                        isValid = false;
                        $rootScope.hide();
                    }

                }
                return isValid;

            }



            $scope.isMobileNoExist = function(mobileNo) {

                $scope.inValidMobileNo = null;
                ConUsers.count({
                        where: {
                            "mobileNumber": mobileNo
                        }
                    },
                    function(value) {
                        if (value.count >= 1 && value.count != 23) {
                            $scope.isDuplicateMobileNo = true;

                            $scope.inValidMobileNo = "Mobile No already Exist";
                            return true;
                        } else {

                            $scope.isDuplicateMobileNo = false;

                            $scope.inValidMobileNo = null;

                        }

                    },
                    function(res) {


                    }
                );
            };

        }
    ]);