/**
 * @ngdoc function
 * @name starter.controller:signUpCtrl
 * @description
 * # signUpCtrl
 * signUp controller of the app
 */
'use strict';
angular.module('ionicControllers')
    .controller('signUpCtrl', ['$rootScope', '$scope', '$timeout', '$cordovaDialogs', '$ionicLoading', '$state', '$ionicModal', '$filter', '$http', '$localStorage', 'ENV', 'API', 'ConUsers', 'CustomerDetails', 'UserRoles', 'Cities',
        function($rootScope, $scope, $timeout, $cordovaDialogs, $ionicLoading, $state, $ionicModal, $filter, $http, $localStorage, ENV, API, ConUsers, CustomerDetails, UserRoles, Cities) {
            $scope.invalidFirstName = null;
            $scope.invalidLastName = null;
            $rootScope.smsFlag = true;
            $scope.inValidEmail = null;
            $scope.inValidMobileNo = null;
            $scope.inValidAddress = null;
            $scope.inValidPassword = null;
            $scope.inValidAddress2 = null;
            $scope.insertFlag = true;
$scope.subMenu =false;

            $scope.addressLat = null;
            $scope.addressLon = null;
            $scope.addressLine2 = null;

            $ionicModal.fromTemplateUrl('templates/search-address-modal.html', function($ionicSearchModal) {
                $scope.searchModal = $ionicSearchModal;
            }, {
                 
                scope: $scope,
                 
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true,
                focusFirstInput: true
            }).then(function(searchModal) {
                $scope.searchModal = searchModal;
                
            });
             $scope.operationCity = function() {
                  Cities.find({
                           
                   },function(citysuccess){
                       
                      $rootScope.cityAt = [];
        for(var i = 0; i<citysuccess.length; i++){
            
            if(citysuccess[i].cityName !== 'All'){
                $rootScope.cityAt.push(citysuccess[i].cityName);
            }
        }


                   },function(cityerr){ 
                 
                   });
              }


            $scope.goToSearchLocation = function(searchLocation) {

                $http.get('https://maps.googleapis.com/maps/api/geocode/json?address=' + searchLocation + 'CA&key=AIzaSyDk68Pkmc9ifI9Vkcl_W7uE1AEsORUNRl4')
                    .then(function successCallback(response) {
                        
                        $scope.addressLat = response.data.results[0].geometry.location.lat;
                        $scope.addressLon = response.data.results[0].geometry.location.lng;
                      
                        $scope.closeSearchModal();
                        $scope.addressLine2 = searchLocation;
                        $scope.position = response.data.results[0].geometry.location;
                          }, function errorCallback(response) {
                        $rootScope.search = 0;
                        
                    });
            };





            $scope.getSearchResult = function(searchText) {
                var url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=' + searchText + '&types=geocode&language=en&key=' + ENV.googlePlacesAPIKey;
                $http.get(url)
                    .then(function successCallback(response) {
                        if (angular.isDefined(response.data.predictions)) {
                           
                        }
                        $scope.searchResult = response.data.predictions;
                    }, function errorCallback(response) {
                        
                    });
            };







            $scope.closeSearchModal = function() {
                
                $scope.searchModal.hide();
            };

            $scope.setAddress = function() {
                $scope.searchModal.show();
            };

            function ifExist(mobileno) {
                ConUsers.count({
                        where: {
                            mobileNumber: mobileno
                        }
                    },
                    function(value) {
                        
                        if (value.count > 0) {
                            $scope.inValidMobileNo = 'Mobile Number Already Exist';
                        }
                    },
                    function(error) {
                        
                    });
            }
            $scope.signUp = function(user) { 
                $rootScope.show();
                signUpValidation(user);
                 
                var localaddress = user.address + ',' + user.address1;
                var deviceName = 'A';
                if ($scope.insertFlag) {
                    ConUsers.createCustomerForCustomerApp({
                        mobileNumber:user.userMobileNo,
                        email:$filter('lowercase')(user.email),
                        firstName: user.firstName,
                        lastName: user.lastName,
                        username: user.userMobileNo,
                        password: ''+user.userMobileNo,
                        otp: $rootScope.OTP,
                        landmark: localaddress,
                        addressLat: 0,
                        addressLong:0,
                        address: $scope.user.addressLine2,
                        userDevice: deviceName,
                        operationCity:user.operationCity
                    },function(registersuccess){
                         
                        if(registersuccess[0].create_customer=== '0'){

                                sendsmsToCustomer(user);
                              ConUsers.login({
                                                                username:'' +user.userMobileNo+ '',
                                                                password:'' + user.userMobileNo+ ''
                                                            },
                                                            function(value) {
                                                                
                                                                $rootScope.user = value.user;
                                                                $rootScope.user.mNumber = user.userMobileNo;
                                                                $localStorage.user = value.user;
                                                                $localStorage.user = {
                                                                    'mobileno': user.userMobileNo,
                                                                    'password': user.userMobileNo
                                                                };
                                                                $rootScope.hide();
                                                                $cordovaDialogs.alert('Welcome to Indian Drivers!', 'Alert');
                                                                 fetchCustomerDetail();
                                                               $state.go('newBooking');
                                                            },
                                                            function(res) {
                                                                $rootScope.hide();

                                                                $cordovaDialogs.alert('Please login.', 'Login');
                                                               $state.go('signIn');

                                                            });
                        }else if(registersuccess[0].create_customer === '1'){
                            $rootScope.hide();
                           $cordovaDialogs.alert('User already exist.', 'Alert');
                           $state.go('signIn');
                        }else{
                            $scope.inValidEmail ='Email already exist.'
                            $rootScope.hide();
                            
                        }
                    },function(registererror){
                        $cordovaDialogs.alert('Error occurred in the registration process. Please try again.', 'Alert');
                    });
                  
                }

            };

            

            function sendsmsToCustomer(user){
                var msg = 'Dear ' + user.firstName + ', Thank you for registering with Indian Drivers.';
                if($rootScope.smsFlag === true){
                ConUsers.sendSMS({
                    mobileNumber: user.userMobileNo,
                    msg: msg
                },function(mgssuccess){
                    
                    $rootScope.smsFlag =false;
                },function(error){

                    
                    $rootScope.smsFlag =false;
                
                });
            }
        };



            function signUpValidation(user) {
                $scope.invalidFirstName = null;
                $scope.invalidLastName = null;

                $scope.inValidEmail = null;
                $scope.inValidMobileNo = null;
                $scope.inValidAddress = null;
                 
                $scope.inValidAddress2 = null;
                  
                $scope.insertFlag = true;
                 $scope.invalidCity = null;

                $scope.addressLine2ForValidation = $scope.addressLine2;
 
                
                 $scope.insertFlag = true;
                if (angular.isUndefined(user)) {
                    $scope.insertFlag = false;
                    $scope.invalidFirstName = 'Enter First Name.';
                    $scope.invalidLastName = 'Enter Last Name.';

                    $scope.inValidEmail = 'Enter Email.';
                    $scope.inValidMobileNo = ' Enter Mobile Number.';
                    $scope.inValidAddress = 'Enter Address.';
                    $scope.inValidAddress2 = 'Enter Location';
                      $scope.invalidCity = 'City is Compulsory'
                    $rootScope.hide();
                      
                } else {
                     
                    if (angular.isUndefined(user.firstName) || user.firstName == '') {
                        $scope.insertFlag = false;
                        $scope.invalidFirstName = 'Enter First Name.';
                        $rootScope.hide();
                    }
                    if (angular.isUndefined(user.lastName) || user.lastName == '') {

                        $scope.insertFlag = false;
                        $scope.invalidLastName = ' Enter Last Name.';
                        $rootScope.hide();
                    } 
                    if (angular.isUndefined(user.email)) {
                        $scope.insertFlag = false;
                        $scope.inValidEmail = 'Enter Email. ';
                        $rootScope.hide();
                    } else {
                        var mailTest = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                        if (!mailTest.test(user.email)) {
                            $scope.insertFlag = false;
                            $scope.inValidEmail = 'Please enter valid Email';
                            $rootScope.hide();
                        }
                    } 
                    if (angular.isUndefined(user.address)) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress = 'Enter Address.';
                        $rootScope.hide();
                    } else if (user.address == '' && user.address1) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress = 'Address field can not be blank.';
                        $rootScope.hide();
                    } else {
                         
                    }
                    if (angular.isUndefined(user.operationCity) || user.operationCity === '' || user.operationCity === null) {
                        $scope.insertFlag = false;
                        $scope.invalidCity = 'City is Compulsory';
                        $rootScope.hide();
                    }
                  /*if (angular.isUndefined($scope.addressLine2ForValidation)) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress2 = 'Enter Google Address.';
                        $rootScope.hide();
                    }  
                    else if ($scope.addressLine2ForValidation == '' || $scope.addressLine2ForValidation == null) {
                        $scope.insertFlag = false;
                        $scope.inValidAddress2 = 'Google Address field can not be blank.';
                        $rootScope.hide();
                    } else {
                         
                    }*/
                     
                     
                }
            }

            function fetchCustomerDetail() {
                CustomerDetails.find({
                        filter: {
                            where: {
                                conuserId: $rootScope.user.id
                            }
                        }

                    },
                    function(response) {
                        $rootScope.hide();
                        if (response.length === 0) {
                            $scope.errorMsg = 'Please Login through Customer Account';
                        } else {
                            $rootScope.user.customerId = response[0].id;
                            $localStorage.user.customerId = response[0].id;
                            

                            if ($rootScope.user.mobileNumber === null || $rootScope.user.mobileNumber === '' || angular.isUndefined(JSON.stringify($rootScope.user.mobileNumber))) {
                                 
                            } else if ($scope.isAutoLogin) {
                                 } else {
                                 
                                 
                            }
                        }
                    },
                    function(error) {
                        $rootScope.hide();
                        $cordovaDialogs.alert(JSON.stringify(error));
                    });

            }

        }
    ]);
