/**
 * @ngdoc function
 * @name starter.controller:MenuCtrl
 * @description
 * # MenuCtrl
 * Menu controller of the app
 */
'use strict';
angular.module('ionicControllers')
    .controller('MenuCtrl', ['$scope', '$localStorage', '$rootScope', '$ionicModal', '$mdSidenav', '$mdComponentRegistry', '$state', 'API', '$cordovaDialogs', 'CustomerDetails', 'Bookings', 'RateCard', '$sce', '$ionicScrollDelegate' ,'$location', 'RatingQuestions', '$ionicPopup', 'Cities', '$mdMenu',
        function($scope, $localStorage, $rootScope, $ionicModal, $mdSidenav, $mdComponentRegistry, $state, API, $cordovaDialogs, CustomerDetails, Bookings, RateCard, $sce, $ionicScrollDelegate, $location, RatingQuestions, $ionicPopup, Cities, $mdMenu) {

            $scope.isNavIconOpened = false;
            $scope.down = true;
            $scope.subMenu = false;
            var originatorEv;
            $scope.$watch(function() {
                return $mdComponentRegistry.get('map-left') ? $mdSidenav('map-left').isOpen() : false;
            }, function(newVal) {
                $scope.isNavIconOpened = newVal;
                
                var currentState = $state.$current.self.name;
                
                if ($scope.isNavIconOpened === false && angular.isDefined($rootScope.map) && $rootScope.map !== null && currentState === 'newBooking') {
                    $rootScope.map.setClickable(true);
                } else if ($scope.isNavIconOpened === false && angular.isDefined($rootScope.map1) && $rootScope.map1 !== null && currentState === 'currentBooking') {
                    $rootScope.map1.setClickable(true);
                } 
            });

            $scope.closeOthers = function() {
                    $mdMenu.hide(null, {
                        closeAll: true
                    });
                };
            
    $scope.toggleLeft = function() {

                isCurrentBooking();

                $scope.isNavIconOpened = !$mdSidenav($rootScope.menuComponentId).isOpen();

                

                var currentState = $state.$current.self.name;

                
                if ($scope.isNavIconOpened) {
                    if (angular.isDefined($rootScope.map) && $rootScope.map !== null) {
                        $rootScope.map.setClickable(false);
                    }
                    if (angular.isDefined($rootScope.map1) && $rootScope.map1 !== null) {
                        $rootScope.map1.setClickable(false);
                    }
                    $mdSidenav($rootScope.menuComponentId).open();
                } else {
                    $mdSidenav($rootScope.menuComponentId).close();
                    if (angular.isDefined($rootScope.map) && $rootScope.map !== null && currentState === 'newBooking') {
                        $rootScope.map.setClickable(true);
                    }
                    if (angular.isDefined($rootScope.map1) && $rootScope.map1 !== null && currentState === 'currentBooking') {
                        $rootScope.map1.setClickable(true);
                    }
                     

                }

            };

             Cities.find({
                           
                   },function(citysuccess){
                       
                      $rootScope.operationCities = [];
        for(var i = 0; i<citysuccess.length; i++){
            
            if(citysuccess[i].cityName !== 'All'){
                $rootScope.operationCities.push(citysuccess[i].cityName);
            }
        }


                   },function(cityerr){ 
                 
                   });

             Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;

                                console.log(s);
                                 
                                
                        },function(r){
                    });
              
            $scope.openMenu = function($mdOpenMenu, ev) {
                    $scope.closeOthers();
                    originatorEv = ev;
                    $mdOpenMenu(ev);
                };

                $scope.setOperationCity = function(index) {
                    $rootScope.show();
                    $rootScope.operationCity = $rootScope.operationCities[index];
                    console.log($rootScope.operationCities[index]);
                    Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCities[index]
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;

                                console.log(s);
                                $scope.rateCardData();
                                $scope.showRateCard();
                                $rootScope.hide();
                        },function(r){
                    });
                };
             
                $scope.openCallModel = function(){
                    $mdSidenav($rootScope.menuComponentId).close()
                    .then(function() {
                        
                    });
                    
                    $state.go('call');
                    //$scope.callModal.show();
                };
                $scope.closeCallModel = function(){
                    $scope.callModal.hide();
                };



            $scope.redirectToURL = function(stateName, menuComponentId) {   
                $state.go(stateName);
                $scope.close();
                $rootScope.menuComponentId = menuComponentId;
            };
            $scope.open = function () {
              if($scope.subMenu){
                $scope.subMenu =false;
              }else{
                $scope.subMenu =true;
              }
              
   /* $ionicPopup.show({
      templateUrl: 'orderPopup.html',
      title: 'Call Us',
      scope: $scope,
      buttons: [{
        text: 'Yes',
        type: 'button-positive',
        onTap: function (e) {
          console.log($scope.choice);
        }
      }, {
        text: 'No',
        type: 'button-default',
        onTap: function (e) {
          $state.go('shoppingCart');
        }
      }]
    });*/
  }
  $scope.value= null;
             $scope.CallNumber = function(number){ 

       console.log('n  :' +number);
    window.plugins.CallNumber.callNumber(function(){
     //success logic goes here
    }, function(){
     //error logic goes here
    }, number) 
  };

$scope.lookPdriver = function() {   
                $state.go('lookingPdirver');
                $scope.close();
                $rootScope.menuComponentId = 'lookingPdirver-left';
            };
            
            $scope.redirectToLogout = function(stateName, menuComponentId) {
                $rootScope.hide();
                if (angular.isDefined($rootScope.map) && $rootScope.map !== null) {
                    $rootScope.map.setClickable(true);
                    $rootScope.map.remove();
                    $rootScope.map = null;
                    
                } 
                $rootScope.OTP = undefined;
                delete $rootScope.user;
                delete $localStorage.user;
                delete $localStorage.canAutologin;
                //delete $localStorage.user.customerId

                $state.go(stateName);
                $rootScope.menuComponentId = menuComponentId;
                $scope.close();
            };

            $scope.close = function() {
                $mdSidenav($rootScope.menuComponentId).close()
                    .then(function() {
                        
                    });
                    $scope.subMenu =false;
            };
            $scope.rateCardData = function(){
            Cities.findOne({
                        filter:{
                           where:{
                            cityName:$rootScope.operationCity
                        } 
                        }
                        
                        },function(s){
                            $rootScope.operationCityId=s.id;
                                console.log(s);
               RateCard.find({
                  filter: {
                       where: {
                        type:'Customer',
                   operationCityId:$rootScope.operationCityId
                 }
               }
               },
               function(rateCardsuc){
                   
                   $scope.rateCardDetail = $sce.trustAsHtml(rateCardsuc[0].rateCardHtml);

               },
               function(ratecarderr){
                   
               });

               },function(r){
                    });
           }
           $scope.scroll = function() {
    $timeout(function () {
       $scope.scrolling = true; 
    
    });
};
$scope.scrollb = function() {
    $timeout(function () {
       $scope.scrolling = false; 
      $ionicScrollDelegate.resize();
    });
  };
           $scope.getScrollPosition = function(){
   console.log($ionicScrollDelegate.getScrollPosition().top);
   if($ionicScrollDelegate.getScrollPosition().top > 200){
                    $scope.down =false;  
                  }else{
                    $scope.down =true; 
                  }
   
}
            $scope.scrollTo = function(target){
                 $location.hash(target);   //set the location hash
            var handle = $ionicScrollDelegate.$getByHandle('myPageDelegate');
                    handle.anchorScroll(true);  // 'true' for animation
                    if(target === 'Contact'){
                      $scope.down =false;  
                  }else{
                    $scope.down =true; 
                  }
                    
                 };

            function isCurrentBooking() {
                $rootScope.currentBookingDisable = false;

                CustomerDetails.find({
                        filter: {
                            where: {
                                conuserId: $rootScope.user.id
                            }
                        }
                    },
                    function(response) {
                        
                        $scope.customerId = response[0].id;
                        Bookings.find({
                                filter: {
                                    where: {
                                        customerId: $scope.customerId,
                                        startOffDuty: true
                                    }
                                }
                            },
                            function(response) {
                                
                                if (response.length > 0) {
                                    $rootScope.currentBookingDisable = true;
                                    $rootScope.currentBooking = response;
                                }
                                $rootScope.currentBookingDisable = true;
                            },
                            function(error) {
                                 
                            });



                    },
                    function(error) {
                        //$cordovaDialogs.alert('Error in Fetching Customer Id', 'Current Booking');
                    });


            }


            $scope.showRateCard = function() {   
                $state.go('rateCard');
                $scope.close();
                $rootScope.menuComponentId = 'rateCard-left';
            };
            $scope.aboutUs= function() {  
               $state.go('aboutUs');
               $scope.close();
               $rootScope.menuComponentId = 'aboutus-left';
           };
        }
    ])
app.directive('scrollOnClick', function() {
  return {
    restrict: 'EA',
    template:'<a title="Click here to go top" class="scrollup" href="#" >Scroll</a>',
    link: function(scope, $elm) {
$(window).scroll(function () {
            if ($(this).scrollTop() > 300) {
                $('.scrollup').fadeIn();
            } else {
                $('.scrollup').fadeOut();
            }
    });   
      $elm.on('click', function() {
        //alert('hello');
        $("html,body").animate({scrollTop: 0}, "slow");
      });
    }
  }
});
