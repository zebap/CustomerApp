
/**
 * @ngdoc function
 * @name starter.controller:invoiceCtrl
 * @description
 * # invoiceCtrl
 * Invoice controller of the app
 */
'use strict';
angular.module('ionicControllers')
    .controller('invoiceCtrl', ['$rootScope', '$scope', '$state', 'ENV', 'API', '$ionicModal',
        function($rootScope, $scope, $state, ENV, API, $ionicModal) {
            $scope.appLogo = ENV.appLogo;
            console.log('In invoice controller');
            $scope.subMenu =false;

            $scope.redirectToURL = function(url, menuComponentId) {
                 
                $rootScope.menuComponentId = menuComponentId;
                $state.go(url);
            };
            
                

            $scope.viewInvoiceDetail = function() {
                console.log('I a in view Invoice Detail');
                $rootScope.menuComponentId = 'invoice-left';
                $rootScope.viewDetailFooter = 'Mail Invoice';
                $state.go('invoice');
            };


        }
    ]);
