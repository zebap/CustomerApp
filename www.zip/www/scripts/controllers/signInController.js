/**
 * @ngdoc function
 * @name starter.controller:signInCtrl
 * @description
 * # signInCtrl
 * Sign-in controller of the app
 */
'use strict';
angular.module('ionicControllers', [])
    .controller('signInCtrl', ['$rootScope', '$scope', '$state', '$filter', '$ionicViewService', '$ionicModal', '$ionicLoading', '$cordovaFacebook', '$cordovaDialogs', 'ENV', 'ConUsers', 'CustomerDetails', '$http', '$localStorage', 'API', '$ionicHistory', '$timeout', 'Bookings', 'DriverDetails', 'UserRoles', 'RatingQuestions', 'BookingRating',
        function($rootScope, $scope, $state,  $filter, $ionicViewService, $ionicModal, $ionicLoading, $cordovaFacebook, $cordovaDialogs, ENV, ConUsers, CustomerDetails, $http, $localStorage, API, $ionicHistory, $timeout, Bookings, DriverDetails, UserRoles, RatingQuestions, BookingRating) {

            console.log('In signIn controller');
            // http://carreto.pt/tools/android-store-version/?package=com.consrv.android.concustomer
            var version = "11.0.0";
            $scope.rateID = [];
             
            version = version.replace(/\./g, "");
            console.log(version);
             $rootScope.rcvdOTP=null;
             var num = parseFloat("9.0.0");
             console.log(num);        
            $rootScope.appLogo = ENV.appLogo;
            $rootScope.userIcon = ENV.userIcon;
            $scope.errorMsg = null;
            $scope.inValidMobileNo = null;
            $scope.mobileNoFlag = true;
            $rootScope.allReadyLogin = false;
            $scope.isAutoLogin = false;
            $rootScope.serverUrl = null;
            
            $ionicModal.fromTemplateUrl('templates/otp-authentication-fail-modal.html', function($ionicOTPFailModal) {
                $scope.otpFail = $ionicOTPFailModal;
            }, {
                 
                scope: $scope,
                 
                animation: 'slide-in-left',
                backdropClickToClose: false,
                hardwareBackButtonClose: true
            }).then(function(otpFail) {
                $scope.otpFail = otpFail;
                
            });
 function checkValidmobileNo(mobileno) {
                var isValid = true;
                $scope.inValidMobileNo = null;
                var mob = /^[0-9]{1,10}$/;
                $scope.mobileNoFlag = true;
                if (angular.isUndefined(mobileno) || mobileno === null) {
                    $scope.mobileNoFlag = false;
                    isValid = false;

                    $scope.inValidMobileNo = 'Mobile number is compulsory';
                    $rootScope.hide();
                } else if(angular.isDefined(mobileno)){
                    if (mobileno.toString().length != 10) {
                        $scope.mobileNoFlag = false;
                        isValid = false;
                        $scope.inValidMobileNo = 'Mobile number should be 10 digit';
                        $rootScope.hide();
                    }
                    
                } else if(angular.isDefined(mobileno)){
                    if(mob.test(mobileno.toString()) == false) {
                    $scope.mobileNoFlag = false;
                    isValid = false;
                        $scope.inValidMobileNo = 'Please enter valid mobile number.';
                        $rootScope.hide();
                    }
                    
                }else{
                     
                }
                return isValid;

            }
$scope.converToTwelveHour = function(time) {
                if (!angular.isUndefined(time)) {
                    var hours = time.split(':')[0];
                    var minutes = time.split(':')[1];
                    var ampm = hours >= 12 ? 'pm' : 'am';
                    hours = hours % 12;
                    hours = hours ? hours : 12;
                    if (minutes === '00') {
                        minutes = '00';
                    } else {
                        minutes = minutes < 10 ? minutes : minutes;
                    }
                    var strTime = hours + ':' + minutes + ' ' + ampm;
                }
                return strTime;
            };
            $rootScope.getMobileOperatingSystem = function() {
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;

      // Windows Phone must come first because its UA also contains "Android"
    if (/windows phone/i.test(userAgent)) {
        return "Windows";
        console.log('Windows Phone');
    }

    if (/android/i.test(userAgent)) {
        return "Android";
        console.log('Android Phone');
    }

    // iOS detection from: http://stackoverflow.com/a/9039885/177710
    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
        return "iOS";
        console.log('iOS Phone');
    }
    
   // return "unknown";
}


            $scope.signIn = function(mobileno) {
                $rootScope.mobileno = mobileno;
                      
                    $rootScope.show();
                    
                    $scope.loginResult = ConUsers.login({
                        username: '' + mobileno + '',
                        password: '' + mobileno + ''
                    },
                    function(value) {
                         $rootScope.operationCity =value.user.operationCity;
                       console.log('id: '+JSON.stringify(value));
                        $rootScope.ConUsers = value;
                        $rootScope.user = value.user;
                         
                            $rootScope.landmark = $rootScope.user.address;
                            $rootScope.conuserId =value.user.id;
                            $rootScope.pickupAddress = $rootScope.user.addressLine2;
                        var id = value.user.id;
                        var deviceName = 'A';
                        ConUsers.findById({
                            id:id

                        },
                        function(success){
                           
                            success.userDevice = deviceName;
                            success.$save();
                            //fetchCustomerDetails();
                             console.log('success update:'+JSON.stringify(success));

                        },
                        function(error){
                              console.log('error:'+JSON.stringify(error));
                        });
                      

                        verifyMobileNo($rootScope.ConUsers.user.mobileNumber);
                          $rootScope.hide();
                
                            
                    },
                     function(res){
                        if (res.status === 401) {
                           $scope.inValidMobileNo = 'Please enter valid credentials';
                            $rootScope.hide();
                        }else if(res.status === 400){
                            $rootScope.hide();
                            $scope.inValidMobileNo = 'Please enter valid mobile no.';
                        }else{
                            $rootScope.hide();
                            $scope.inValidMobileNo = 'Sorry you are not connected to the Internet, please try again later. ';
                            
                        }
                    });
               
                
            };

            $scope.isExistMobile = function(mobileno){
                $rootScope.show();

                $rootScope.user=undefined;
                 $localStorage.user=undefined;
                $localStorage.canAutologin=undefined;
                
                $rootScope.mobileno = mobileno;
                 var isValid = checkValidmobileNo($rootScope.mobileno);
                  
                     
                if(isValid){
                    ConUsers.validateCustomerMobile({
                        mobileNumber: mobileno
                    },function(checkuser){
                        console.log('user check : ' +JSON.stringify(checkuser));
                         
                        if(checkuser[0].validate_customer_mobile === '0'){
                          $scope.signIn(mobileno);
                        }else if(checkuser[0].validate_customer_mobile === '1'){
                            verifyMobileNo(mobileno);
                                $rootScope.hide();
                        }else if(checkuser[0].validate_customer_mobile === '2'){
                            $rootScope.hide();
                            $cordovaDialogs.alert('Your registration is in progress. For more details please contact 020-67641000', 'Alert');
                            $state.go('signIn');
                        }else if(checkuser[0].validate_customer_mobile === '4'){
                            $rootScope.hide();
                            $cordovaDialogs.alert('Your registration is in progress. For more details please contact 020-67641020', 'Alert');
                            $state.go('signIn');
                        }else if(checkuser[0].validate_customer_mobile === '3'){
                            $scope.inValidMobileNo = 'You cannot login by this number.';
                            $rootScope.hide(); 

                        }else{


                        }
                    },function(usererror){
                        
                         $cordovaDialogs.alert('Service unavailable. Please try later. ');
                         $rootScope.hide();


                    });
                  
             }
             
                 
            };

             function verifyMobileNo(mobileno) {
                 if(angular.isDefined($rootScope.OTP)){
                        $rootScope.OTP = null;
                    }

                if (!$scope.mobileNoFlag && mobileno != '') {
                    $ionicViewService.nextViewOptions({
                    disableBack: true
                    });
                    $ionicViewService.clearHistory();
            $ionicHistory.clearHistory();
                    $state.go('verifOTPNo');
                     
                    return;
                } else {
                    if (mobileno === '') {
                        mobileno = $rootScope.mobileno;
                        

                    }
                    $rootScope.mobileno = mobileno;
                  
                    
                    if(angular.isDefined($rootScope.OTP)){
                        $rootScope.OTP = null;
                    }
                    $rootScope.OTP = Math.floor(Math.random() * 90000) + 10000;
                     
                  

                  

                  var success = sendSms(mobileno, $rootScope.OTP);
                             
                            $ionicViewService.nextViewOptions({
                            disableBack: true
                                });
                            $ionicViewService.clearHistory();
                            $ionicHistory.clearHistory();
                            $state.go('verifOTPNo');

                        
                }
            }
            
             
            
            $scope.signUp = function() {
                $rootScope.show();
                 $state.go('signUp');
                $rootScope.hide();
            };

             

            function fetchCustomerDetails() {
                  
                 
                CustomerDetails.findOne({
                        filter: {
                            where: {
                                conuserId: $rootScope.ConUsers.user.id
                            }
                        }
                    },
                    function(success) {
                        
                        $rootScope.customerDetails = success;
                        $rootScope.customerId = success.id;
                          
                            $localStorage.user.customerId = success.id;
                         
                    },
                    function(error) {
                         
                    });
            };
            function updateOtp(otp){
                ConUsers.findById({
                    id:$rootScope.ConUsers.user.id
                },
                function(updateotp){
                    
                    $scope.updateotp =updateotp;
                    $scope.updateotp.updatedDate= new Date();
                    $scope.updateotp.updatedBy = $rootScope.ConUsers.user.id;
                    $scope.updateotp.otp = otp;
                    $scope.updateotp.$save();

                },
                function(updateerror){
                });
            }




 
            function paymentOperation() {
                var dated = new Date('06/01/2017');
                console.log(dated);
                $rootScope.show();
                    var customer_id = $localStorage.user.customerId;
                Bookings.find({
                        filter: {
                            where: {
                         and:[{customerId: $localStorage.user.customerId},{feedbackStatus: 'Initiated'}]
                                
                                
                                    
                            }
                        }
                    },
                    function(response) {
                       console.log('response ' + JSON.stringify(response));
                         
                        if (response.length !== 0) {
                             
                            $scope.makePendingPayment(response[0].id);
                        } else {
                            $ionicViewService.nextViewOptions({
                    disableBack: true
                    });
                    $ionicViewService.clearHistory();
                    $ionicHistory.clearHistory();
                            $state.go('newBooking');
                            $rootScope.hide();
                        }

                    },
                    function(error) {
                        
                    });
            }


            $scope.makePendingPayment = function(bookingId) {
                 $scope.loadingIndicator = $ionicLoading.show({
                                                template: '<ion-spinner icon="spiral"></ion-spinner>'

                                                });
                Bookings.find({
                        filter: {
                            where: {
                                id: bookingId
                            },
                            include: [{
                                relation: 'invoices',
                                scope: {
                                    include: {
                                        relation: 'invoiceDetails',
                                        scope: {
                                            include: {
                                                relation: 'invoiceSubHeads'
                                            }
                                        }
                                    },
                                    order: 'id DESC',
                                    limit: 1
                                }
                            }, {
                                relation: 'localBookings'
                            }, {
                                relation: 'outstationBookings'
                            }]
                        }
                    },
                    function(response) {
                       
                        $rootScope.bookingDetail = response;
                        if(angular.isDefined($rootScope.bookingDetail[0].outstationBookings[0])){
                             if($rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime !== null){
                            var returnTime = $rootScope.bookingDetail[0].outstationBookings[0].returnTravelTime.toFixed(2);
                           var array = returnTime.split('.');
                     var returnTravelHour = parseInt(array[0]);
                     var returnTravelMinute = parseInt(array[1]); 
                        if (returnTravelMinute < 10) {
                                    returnTravelMinute = '0' + returnTravelMinute;
                                }
                                returnTravelMinute = returnTravelMinute * 0.6;
                                returnTravelMinute = Math.round(returnTravelMinute);
                        }        $rootScope.time2 = returnTravelHour + ' Hours ' + returnTravelMinute +' Minutes'; 
                        }
                        $rootScope.baseFare = null;
                        $rootScope.returnFare = null;

                         if (response[0].driverId != null) {
                              DriverDetails.find({
                                    filter: {
                                        where: {
                                            id: response[0].driverId
                                        },
                                        include: {
                                            relation: 'conUsers'
                                        }


                                    }
                                },
                                function(response) {
                                    $rootScope.driverDetailOfViewBooking = response;
                                    $rootScope.hide();
                                },
                                function(error) {
                                    $cordovaDialogs.alert('Error in fetching Driver Detail', 'My Booking');
                                });


                        }
                        $rootScope.viewInvoiceDetail = response[0].invoices[0].invoiceDetails;
                         $ionicLoading.hide();
                    },
                    function(error) {
                        
                    });
                $rootScope.menuComponentId = 'invoice-left';
                $rootScope.viewDetailFooter = 'Cancel Booking';

                if (angular.isDefined($rootScope.map)) {

                    if ($rootScope.map !== null) {
                        $rootScope.map.setClickable(false);
                    }

                }
                $ionicViewService.nextViewOptions({
                    disableBack: true
                    });
                    $ionicViewService.clearHistory();
                    $ionicHistory.clearHistory();
                   //$state.go('feedback');
                $state.go('makePendingPayment');
                $rootScope.hide();
                 $ionicLoading.hide();
            }

            


            $scope.check = function(rateId) {
              if ($scope.rateID.indexOf(rateId) == -1){
                $scope.rateID.push(rateId);
              }else{
                for (var i = $scope.rateID.length - 1; i >= 0; i--) {

                        if ($scope.rateID[i] == rateId) {
                            $scope.rateID.splice(i, 1);
                         }

                    }
              }
              
              if(rateId === 4 || rateId ===10 || rateId ===16 || rateId===22 || rateId===28){
                if($rootScope.comment === true){
                  $rootScope.comment = false;
                }else{
                  $rootScope.comment = true;
                }
                
              }
          console.log('id ' + JSON.stringify($scope.rateID));
           // body...
         }
         $scope.ratingsObject = {
        iconOn : 'ion-ios-star',
        iconOff : 'ion-ios-star-outline',
        iconOnColor: 'rgb(200, 200, 100)',
        iconOffColor:  'rgb(200, 100, 100)',
        rating:  2,
        minRating:1,
        callback: function(rating) {
          $scope.ratingsCallback(rating);
        }
      };
        
         $scope.ratingsCallback = function(rating) {
            $rootScope.comment = false;
            $scope.rateID =[];
        $scope.ratingsObjectData =[];
       RatingQuestions.find({
            filter:{
              where:{
                rating:rating
              }
            }
       },function(success) {
         
          $scope.ratingsObject = {
        iconOn : 'ion-ios-star',
        iconOff : 'ion-ios-star-outline',
        iconOnColor: 'rgb(200, 200, 100)',
        iconOffColor:  'rgb(200, 100, 100)',
        rating:  success[0].rating,
        ratingDescription:success[0].ratingDescription,
        minRating:1,
        callback: function(rating) {
          $scope.ratingsCallback(rating);
        }
      };
      $rootScope.ratingCount = $scope.ratingsObject.rating;
        for(var i=0;i<success.length;i++){
          $scope.ratingsObjectData.push({
        iconOn : 'ion-ios-star',
        iconOff : 'ion-ios-star-outline',
        iconOnColor: 'rgb(200, 200, 100)',
        iconOffColor:  'rgb(200, 100, 100)',
        id:success[i].id,
        rating:  success[0].rating,
        ratingDescription:success[0].ratingDescription,
        questionDescription:success[i].questionDescription,
        minRating:1
         
      });

      
        }
        
         // body...
         console.log('data : '+JSON.stringify(success));
       },function(error) {
         // body...
       });
        console.log('Selected rating is : ', rating);
      };
      $scope.changeTo = function(index) {
        console.log('index' + JSON.stringify(index));
        // body...
      }
      $scope.getAllReasons = function() {
        $rootScope.comment = false;
          // body...
            $scope.ratingsObjectData =[];
       RatingQuestions.find({
            filter:{
              where:{
                rating:5
              }
            }
       },function(success) {
         
          $scope.ratingsObject = {
        iconOn : 'ion-ios-star',
        iconOff : 'ion-ios-star-outline',
        iconOnColor: 'rgb(200, 200, 100)',
        iconOffColor:  'rgb(200, 100, 100)',
        rating:  success[0].rating,
        ratingDescription:success[0].ratingDescription,
        minRating:1,
        callback: function(rating) {
          $scope.ratingsCallback(rating);
        }
      };
      $rootScope.ratingCount = $scope.ratingsObject.rating;
        for(var i=0;i<success.length;i++){
          $scope.ratingsObjectData.push({
        iconOn : 'ion-ios-star',
        iconOff : 'ion-ios-star-outline',
        iconOnColor: 'rgb(200, 200, 100)',
        iconOffColor:  'rgb(200, 100, 100)',
        id:success[i].id,
        rating:  success[0].rating,
        ratingDescription:success[0].ratingDescription,
        questionDescription:success[i].questionDescription,
        minRating:1
         
      });

      
        }
        
         // body...
         console.log('data : '+JSON.stringify(success));
       },function(error) {
         // body...
       });
      }

            function redirectLogin() {
                

                $ionicHistory.clearHistory();
                $ionicHistory.clearCache();
                $ionicHistory.nextViewOptions({
                    disableBack: true
                });
                
                $state.go('signIn');
                $rootScope.hide();
            }

            $scope.signUpPage = function() {
                $rootScope.user = undefined;
                $state.go('signUp'); 
            }

             


             

            
            $scope.verifyOTPNo = function(otpNo) {
                $rootScope.show();
                
                

                        console.log('Entered OTP No' + otpNo);
                        console.log('Existing OTP No' + $rootScope.OTP);

                        if (Number($rootScope.OTP) === Number(otpNo)) {
                      /*     SMS.stopWatch(function(){
                //update('watching', 'watching stopped');
            }, function(){
               // updateStatus('failed to stop watching');
            });
            */
                           ConUsers.validateCustomerMobile({
                        mobileNumber: $rootScope.mobileno
                    },function(checkuser){
                        console.log('checkuser ' +JSON.stringify(checkuser));
                        if(checkuser[0].validate_customer_mobile === '0'){
                          $scope.loginResult = ConUsers.login({
                        username: '' +  $rootScope.mobileno + '',
                        password: '' +  $rootScope.mobileno + ''
                    },
                    function(value) {
                        $rootScope.operationCity =value.user.operationCity;
                        $rootScope.ConUsers = value;
                        $localStorage.user = {
                            'mobileno': $rootScope.mobileno,
                            'password': $rootScope.mobileno
                        }; 
                        fetchCustomerDetails();
                         updateOtp($rootScope.OTP);
                         $rootScope.menuComponentId = 'invoice-left';
                         $rootScope.menuComponentId = 'profile-left';
                        $rootScope.menuComponentId = 'initialProfile-left';
                         $rootScope.viewDetailFooter = 'Cancel Booking';
                 

                if (angular.isDefined($rootScope.map)) {

                    if ($rootScope.map !== null) {
                        $rootScope.map.setClickable(false);
                    }

                }
                            $state.go('myProfileInital');
                            $rootScope.hide();
                         
                        
                    },
                    function(errorvalue){

                    });
                        }else if(checkuser[0].validate_customer_mobile === '1'){
                             $scope.loadingIndicator = $ionicLoading.show({
                                                template: '<ion-spinner icon="spiral"></ion-spinner>'

                                                });
                                                $rootScope.user = {
                                                     
                                                    userMobileNo: $rootScope.mobileno
                                                };
                                                $timeout(function() {

                                                    $ionicLoading.hide();
                                                }, 1500);
                        $state.go('signUp');
                         $rootScope.hide();

                        }else if(checkuser[0].validate_customer_mobile === '2'){
                            $cordovaDialogs.alert('Your registration is in progress. For more details please contact 020-67641000', 'Alert');
                            $state.go('signIn');

                        }else if(checkuser[0].validate_customer_mobile === '4'){
                            $cordovaDialogs.alert('Your registration is in progress. For more details please contact 020-67641020', 'Alert');
                            $state.go('signIn');
                            
                        }else if(checkuser[0].validate_customer_mobile === '3'){
                            $scope.inValidMobileNo = 'You cannot login by this number.'; 

                        }else{


                        }
                         },function(usererror){
                        console.log('usererror ' +JSON.stringify(usererror));


                    });
                }else{


                            $scope.otpFail.show();
                            $rootScope.hide();
                       
                }
                             
            };

            $scope.closeOTPFailModal = function() {
                $scope.otpFail.hide();
            }

            $scope.Feedback = function(bookingId){
                 
                var qId = '{'+$scope.rateID+'}';
                //var qId = qId.replace(/\[/g, '{').replace(/]/g, '}');

                var bId = bookingId ;
                var comment='No Comment'
                console.log(qId);
                     
                 
                  
            feedbackDone(qId , bId , $rootScope.ratingCount , comment); 
                $state.go('newBooking');
              
               
            }
            $scope.Feedback2 = function(bookingId,user){
                 var qId = '{'+$scope.rateID+'}';
                //var qId = qId.replace(/\[/g, '{').replace(/]/g, '}');

                var bId = bookingId ;
                var comment = user;
                //$state.go('newBooking');
                feedbackDone(qId , bId , $rootScope.ratingCount , comment);
                 $state.go('newBooking');
                 
                 
            }
             
             function feedbackDone(qId,bId,rtng,cmnt){
                 
                    BookingRating.submitFeedback({
                    questionId:qId,
                    bookingId:bId,
                    rating:rtng,
                    comment:cmnt
                },function(success){
                    console.log('success');
                   
                },function(error){

                }); 
                     
             }

            function sendSms(mobileno, token) {
                ConUsers.sendSMS({
                    mobileNumber: mobileno,
                    msg: 'Your verification code is ' + token
                }, function(success) {
                     console.log('SMS send successfully' + JSON.stringify(success));
                    
                    /*SMS.startWatch(function(){
       console.log('Watching');
     }, function(){
       console.log('Not Watching');
     });*/
  
     document.addEventListener('onSMSArrive', function(e){
            var data = e.data;
             if(angular.isDefined(data)){
                $ionicLoading.hide();
                  console.log('data: ' +JSON.stringify(data));  
                  var thestring= data.body;
                  var otpnumber = thestring.replace( /^\D+/g, ''); 
             console.log(thestring.replace( /^\D+/g, ''));  
                  if( Number(otpnumber)=== token){
                    $rootScope.otpNo = token;
                    if(angular.isDefined($rootScope.otpNo)){
                $scope.verifyOTPNo($rootScope.otpNo);
             }
                  } 
                      
             }
     });
      
               
                   
                   
                   
                    //$rootScope.hide();
                }, function(error) {
                    console.log('SMS sending error' + JSON.stringify(error));
                });
            }

            



            $scope.autoLogin = function() {
                console.log('Auto login called');
                $rootScope.show();

                if (angular.isUndefined($localStorage.user)) {
                    setInitialVariable();
                    $scope.isAutoLogin = false;
                    $timeout(redirectLogin, 3000);
                } else {
                     setInitialVariable();
                    $scope.isAutoLogin = true;
                    ConUsers.validateCustomerMobile({
                        mobileNumber: $localStorage.user.mobileno
                    },function(checkuser){
                        console.log('user check : ' +JSON.stringify(checkuser));
                         
                        if(checkuser[0].validate_customer_mobile === '0'){
                           ConUsers.login({
                            username: '' + $localStorage.user.mobileno + '',
                            password: '' + $localStorage.user.password + ''

                        },
                        function(value) {
                            $rootScope.operationCity =value.user.operationCity;
                             console.log('Success autologin' + JSON.stringify(value));
                            $rootScope.user = value.user;
                            $rootScope.landmark = $rootScope.user.address;
                            $rootScope.pickupAddress = $rootScope.user.addressLine2;
                            $rootScope.user.customerId=value.user.id
                            $rootScope.ConUsers = value;
                            
                             var id = value.user.id;
                             $rootScope.conuserId = id;
                        var deviceName =  'A';
                        ConUsers.findById({
                            id:id

                        },
                        function(success){
                           

                            success.userDevice = deviceName;
                            success.$save();
                            fetchCustomerDetails();
                             console.log('success update:'+JSON.stringify(success));

                        },
                        function(error){
                              console.log('error:'+JSON.stringify(error));
                        });
                            
                         
                           
                           
                             
                            $ionicViewService.nextViewOptions({
                    disableBack: true
                    });
                    $ionicViewService.clearHistory();
                    $ionicHistory.clearHistory();
                    setInitialVariable();
                    $scope.isAutoLogin = true;
                    if (angular.isDefined($localStorage.user.customerId)){
                               paymentOperation(); 
                               $rootScope.hide();
                            }
                    
                        },
                        function(res) {

                            $rootScope.hide();
                            if (res.status === 401) {
                                delete $localStorage.user;
                                $timeout(redirectLogin, 3000);
                            } else if (res.status === 400) {
                                delete $localStorage.user;
                                $timeout(redirectLogin, 3000);
                            } else {
                                 $rootScope.hide();
                            $cordovaDialogs.alert('Sorry you are not connected to the Internet, please try again later.','Alert');
                                $ionicViewService.nextViewOptions({
                    disableBack: true
                    });
                    $ionicViewService.clearHistory();
            $ionicHistory.clearHistory(); 
                                $state.go('signIn');
                                
                            }
                             
                        });
                        }else if(checkuser[0].validate_customer_mobile === '1'){
                            $state.go('signIn');
                                $rootScope.hide();
                        }else if(checkuser[0].validate_customer_mobile === '2'){
                            $rootScope.hide();
                            $cordovaDialogs.alert('You are no more active to proceed further. For more details please contact 020-67641000', 'Alert');
                            $state.go('signIn');
                        }else if(checkuser[0].validate_customer_mobile === '4'){
                            $rootScope.hide();
                            $cordovaDialogs.alert('You are no more active to proceed further. For more details please contact 020-67641020', 'Alert');
                            $state.go('signIn');
                        }else if(checkuser[0].validate_customer_mobile === '3'){
                             $state.go('signIn');
                            $rootScope.hide(); 

                        }else{


                        }
                    },function(usererror){
                        
                         $cordovaDialogs.alert('Service unavailable. Please try later. ');
                          $ionicViewService.nextViewOptions({
                    disableBack: true
                    });
                    $ionicViewService.clearHistory();
                    $ionicHistory.clearHistory();
                         $state.go('signIn');
                         $rootScope.hide();


                    });
                    
                     
                }
            };

             




            $scope.reSendOTP = function(otp) {
                 
                        sendSms( $rootScope.mobileno, $rootScope.OTP);
                        $cordovaDialogs.alert('OTP resent successfully.','Alert');
                        $state.go('verifOTPNo');
                     
            };

            function setInitialVariable() {
                $rootScope.serverUrl = 'http://52.32.39.44:';
                 
            }
        }
    ])
    .directive('allowPattern', [allowPatternDirective]);

function allowPatternDirective() {
    return {
        restrict: "A",
        compile: function(tElement, tAttrs) {
            return function(scope, element, attrs) {
                 
                element.bind("keypress", function(event) {
                    var keyCode = event.which || event.keyCode;  
                    var keyCodeChar = String.fromCharCode(keyCode);  

                     
                    if (!keyCodeChar.match(new RegExp(attrs.allowPattern, "i"))) {
                        event.preventDefault();
                        return false;
                    }

                });
            };
        }
    };
};
 
